<?php
// leave-management.php
require_once __DIR__ . 'php/connect.php';

// Initialize variables with default values
$leaveStats = [
    'pending' => 0,
    'approved' => 0,
    'rejected' => 0,
    'total_days' => 0
];

$recentRequests = [];
$leaveBalances = [];

try {
    if ($conn) {
        // Get leave request statistics
        $stmt = $conn->query("
            SELECT 
                SUM(CASE WHEN leave_status = 'Pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN leave_status = 'Approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN leave_status = 'Rejected' THEN 1 ELSE 0 END) as rejected,
                SUM(DATEDIFF(end_date, start_date) + 1) as total_days
            FROM leave_requests
        ");
        
        if ($stmt) {
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
            $leaveStats['pending'] = $stats['pending'] ?? 0;
            $leaveStats['approved'] = $stats['approved'] ?? 0;
            $leaveStats['rejected'] = $stats['rejected'] ?? 0;
            $leaveStats['total_days'] = $stats['total_days'] ?? 0;
        }

        // Get recent leave requests with employee names
        $stmt = $conn->query("
            SELECT 
                l.leave_id,
                CONCAT('LV-', l.leave_id) as leave_code,
                CONCAT(e.first_name, ' ', e.last_name) as employee_name,
                l.leave_type,
                l.start_date,
                l.end_date,
                DATEDIFF(l.end_date, l.start_date) + 1 as days,
                l.leave_reason,
                l.leave_status
            FROM leave_requests l
            LEFT JOIN employees e ON l.employee_id = e.employee_id
            ORDER BY l.leave_id DESC
            LIMIT 5
        ");
        
        if ($stmt) {
            $recentRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        // Get leave balances from leave_balances table
        $stmt = $conn->query("
            SELECT 
                CONCAT(e.first_name, ' ', e.last_name) as employee_name,
                MAX(CASE WHEN lb.leave_type = 'Vacation' THEN lb.remaining_credits ELSE 0 END) as vacation,
                MAX(CASE WHEN lb.leave_type = 'Sick' THEN lb.remaining_credits ELSE 0 END) as sick,
                MAX(CASE WHEN lb.leave_type = 'Emergency' THEN lb.remaining_credits ELSE 0 END) as emergency
            FROM employees e
            LEFT JOIN leave_balances lb ON e.employee_id = lb.employee_id
            WHERE e.employment_status IN ('Regular', 'Probationary')
            GROUP BY e.employee_id
            LIMIT 10
        ");
        
        if ($stmt) {
            $leaveBalances = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
} catch(PDOException $e) {
    error_log("Leave Management DB Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Management - Hospital HR</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/modules/leave-management/leave-management.css">
    <style>
        .connection-status {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 20px;
            border-radius: 30px;
            font-size: 14px;
            z-index: 9999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transition: opacity 1s;
        }
        .connection-status.connected {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .connection-status.disconnected {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .table-container {
            max-height: 400px;
            overflow-y: auto;
        }
        .sticky-top {
            z-index: 10;
        }
    </style>
</head>
<body>
    <?php if (isset($conn) && $conn): ?>
        <div class="connection-status connected">
            <i class="fas fa-check-circle me-2"></i> Database Connected
        </div>
    <?php else: ?>
        <div class="connection-status disconnected">
            <i class="fas fa-exclamation-circle me-2"></i> Database Disconnected (Using Sample Data)
        </div>
    <?php endif; ?>

    <main class="container py-4 py-md-5">
        <div class="lm-wrap">
            <section class="lm-header p-4 p-md-5 shadow-sm mb-4">
                <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                    <div>
                        <h1 class="h3 mb-2"><i class="fas fa-calendar-check me-2"></i>Leave Management</h1>
                        <p class="mb-0 opacity-75">Manage leave dashboard, requests, approvals, balances, and reports in one page.</p>
                        <?php if(isset($conn) && $conn): ?>
                            <small class="text-success mt-2 d-block"><i class="fas fa-database me-1"></i> Live data from database</small>
                        <?php else: ?>
                            <small class="text-warning mt-2 d-block"><i class="fas fa-exclamation-triangle me-1"></i> Using sample data (Database not connected)</small>
                        <?php endif; ?>
                    </div>
                    <a href="../dashboard.php" class="btn btn-light">
                        <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                    </a>
                </div>
            </section>

            <section class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <div class="lm-subnav d-flex flex-wrap gap-2" role="tablist" aria-label="Leave Management submodules">
                        <button type="button" class="btn btn-outline-primary active" data-submodule="Leave Dashboard">Leave Dashboard</button>
                        <button type="button" class="btn btn-outline-primary" data-submodule="Leave Request">Leave Request</button>
                        <button type="button" class="btn btn-outline-primary" data-submodule="Leave Approval">Leave Approval</button>
                        <button type="button" class="btn btn-outline-primary" data-submodule="Leave Balance">Leave Balance</button>
                        <button type="button" class="btn btn-outline-primary" data-submodule="Leave Reports">Leave Reports</button>
                    </div>
                </div>
            </section>

            <section class="card border-0 shadow-sm">
                <div class="card-body">
                    <div id="lmSubmoduleContainer"></div>
                </div>
            </section>
        </div>
    </main>

    <script>
        // Pass PHP data to JavaScript
        window.hrLeaveData = {
            stats: {
                pending: <?php echo $leaveStats['pending']; ?>,
                approved: <?php echo $leaveStats['approved']; ?>,
                rejected: <?php echo $leaveStats['rejected']; ?>,
                total_days: <?php echo $leaveStats['total_days']; ?>
            },
            recentRequests: <?php echo json_encode($recentRequests); ?>,
            balances: <?php echo json_encode($leaveBalances); ?>
        };
        
        // Log data for debugging
        console.log('Leave Data loaded:', window.hrLeaveData);
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/modules/leave-management/leave-management.js"></script>
    
    <script>
        // Auto-hide connection status after 5 seconds
        setTimeout(function() {
            var statusDiv = document.querySelector('.connection-status');
            if (statusDiv) {
                statusDiv.style.transition = 'opacity 1s';
                statusDiv.style.opacity = '0';
                setTimeout(function() {
                    statusDiv.style.display = 'none';
                }, 1000);
            }
        }, 5000);
    </script>
</body>
</html>