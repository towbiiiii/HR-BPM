<?php
// php/connect.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hms_hr_db";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // IMPORTANT: Remove or comment out any echo statements here
    // DO NOT put any echo here as it will break JSON responses
    
} catch(PDOException $e) {
    // Log error but don't output anything
    error_log("Connection failed: " . $e->getMessage());
    
    // Re-throw the exception to be handled by the calling code
    throw new PDOException($e->getMessage());
}
?>