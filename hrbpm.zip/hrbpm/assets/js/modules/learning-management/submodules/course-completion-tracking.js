/**
 * Course Completion Tracking Submodule
 * Official Records and Certification Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCompletions';

    const getCompletions = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Completion Records
        return [
            { id: "CERT-901", name: "Dr. Aris Thorne", course: "Advanced Life Support", date: "2026-02-10", grade: "98%", status: "Certified" },
            { id: "CERT-902", name: "Sarah Jenkins", course: "Patient Privacy & HIPAA", date: "2026-01-22", grade: "100%", status: "Certified" },
            { id: "CERT-903", name: "James Miller", course: "Radiology Safety", date: "2025-12-15", grade: "85%", status: "Expired" }
        ];
    };

    function ensureCompletionTrackingModalHost() {
        if (document.getElementById('completionTrackingModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="completionTrackingModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="completionTrackingModalTitle">Completion Registry</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="completionTrackingModalBody"></div>',
            '      <div class="modal-footer" id="completionTrackingModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showCompletionTrackingInfo(title, message) {
        const modalEl = document.getElementById('completionTrackingModal');
        const titleEl = document.getElementById('completionTrackingModalTitle');
        const bodyEl = document.getElementById('completionTrackingModalBody');
        const footerEl = document.getElementById('completionTrackingModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderCourseCompletionTracking = function (container) {
        ensureCompletionTrackingModalHost();

        const data = getCompletions();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-certificate text-success me-2"></i>Completion Registry</h6>
                        <small class="text-muted">Official log of hospital certifications and professional development</small>
                    </div>
                    <button class="btn btn-outline-success btn-sm rounded-pill px-3" onclick="window.HRSubmodules.recordNewCompletion()">
                        <i class="fas fa-file-signature me-1"></i> Record Completion
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-tracking-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Staff Member</th>
                                <th style="width: 30%">Course Title</th>
                                <th style="width: 15%">Grade</th>
                                <th style="width: 15%">Completion</th>
                                <th class="text-end pe-4" style="width: 15%">Credential</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${data.map(item => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${item.name}</div>
                                        <div class="extra-small text-muted">ID: ${item.id}</div>
                                    </td>
                                    <td>
                                        <div class="text-dark small">${item.course}</div>
                                    </td>
                                    <td>
                                        <span class="fw-bold ${parseInt(item.grade) >= 90 ? 'text-success' : 'text-primary'}">${item.grade}</span>
                                    </td>
                                    <td>
                                        <div class="small text-muted">${item.date}</div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <span class="cert-status ${item.status.toLowerCase()}">${item.status}</span>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.recordNewCompletion = function() {
        const modalEl = document.getElementById('completionTrackingModal');
        const titleEl = document.getElementById('completionTrackingModalTitle');
        const bodyEl = document.getElementById('completionTrackingModalBody');
        const footerEl = document.getElementById('completionTrackingModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Record Completion';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="completionStaffName" placeholder="e.g. Dr. Aris Thorne">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Course Completed</label>',
            '  <input type="text" class="form-control form-control-sm" id="completionCourseName" placeholder="e.g. ALS">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Final Grade</label>',
            '  <input type="text" class="form-control form-control-sm" id="completionCourseGrade" placeholder="e.g. 95%">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-success" id="completionRecordBtn">Record</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const recordBtn = document.getElementById('completionRecordBtn');
        if (recordBtn) {
            recordBtn.addEventListener('click', function () {
                const name = (document.getElementById('completionStaffName').value || '').trim();
                const course = (document.getElementById('completionCourseName').value || '').trim();
                const grade = (document.getElementById('completionCourseGrade').value || '').trim() || 'N/A';
                if (!name || !course) {
                    return;
                }

                let data = getCompletions();
                data.unshift({
                    id: 'CERT-' + Math.floor(1000 + Math.random() * 9000),
                    name: name,
                    course: course,
                    date: new Date().toISOString().split('T')[0],
                    grade: grade,
                    status: 'Certified'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderCourseCompletionTracking(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showCompletionTrackingInfo('Completion Saved', 'Completion record has been added for ' + name + '.');
            });
        }

        modal.show();
    };
})();