/**
 * Certifications Submodule
 * Professional License & Board Credential Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrLicenseVault';

    const getCertifications = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Default Medical License Data
        return [
            { id: "LIC-7701", name: "Dr. Aris Thorne", type: "Medical Board License", issued: "2024-05-20", expiry: "2027-05-20", status: "Active" },
            { id: "LIC-8820", name: "Sarah Jenkins", type: "Registered Nurse (RN)", issued: "2023-11-10", expiry: "2026-11-10", status: "Active" },
            { id: "LIC-4412", name: "James Miller", type: "Radiology Tech Cert", issued: "2021-01-05", expiry: "2024-01-05", status: "Expired" }
        ];
    };

    function ensureCertificationsModalHost() {
        if (document.getElementById('certificationsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="certificationsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="certificationsModalTitle">Credential Vault</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="certificationsModalBody"></div>',
            '      <div class="modal-footer" id="certificationsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showCertificationsInfo(title, message) {
        const modalEl = document.getElementById('certificationsModal');
        const titleEl = document.getElementById('certificationsModalTitle');
        const bodyEl = document.getElementById('certificationsModalBody');
        const footerEl = document.getElementById('certificationsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderCertifications = function (container) {
        ensureCertificationsModalHost();

        const certs = getCertifications();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-id-card text-primary me-2"></i>Credential Vault</h6>
                        <small class="text-muted">Monitoring professional licenses and board certifications</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.registerNewLicense()">
                        <i class="fas fa-plus me-1"></i> Register License
                    </button>
                </div>

                <div class="row g-3">
                    ${certs.map(cert => `
                        <div class="col-xl-4 col-md-6">
                            <div class="cert-card bg-white border rounded-4 shadow-sm p-4 h-100 position-relative overflow-hidden">
                                <div class="cert-status-stripe ${cert.status.toLowerCase()}"></div>
                                <div class="d-flex justify-content-between mb-3">
                                    <span class="extra-small text-muted fw-bold">REF: ${cert.id}</span>
                                    <span class="badge ${cert.status === 'Active' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'} rounded-pill" style="font-size: 9px;">${cert.status}</span>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">${cert.name}</h6>
                                <p class="text-primary small fw-semibold mb-4">${cert.type}</p>
                                
                                <div class="d-flex justify-content-between align-items-center bg-light p-2 rounded-3">
                                    <div class="text-center flex-grow-1">
                                        <div class="extra-small text-muted">ISSUED</div>
                                        <div class="small fw-bold text-dark">${cert.issued}</div>
                                    </div>
                                    <div class="border-start mx-2" style="height: 20px;"></div>
                                    <div class="text-center flex-grow-1">
                                        <div class="extra-small text-muted">EXPIRY</div>
                                        <div class="small fw-bold ${cert.status === 'Expired' ? 'text-danger' : 'text-dark'}">${cert.expiry}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.registerNewLicense = function() {
        const modalEl = document.getElementById('certificationsModal');
        const titleEl = document.getElementById('certificationsModalTitle');
        const bodyEl = document.getElementById('certificationsModalBody');
        const footerEl = document.getElementById('certificationsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Register License';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Professional Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="certNameInput" placeholder="e.g. Dr. Aris Thorne">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">License Type</label>',
            '  <input type="text" class="form-control form-control-sm" id="certTypeInput" placeholder="e.g. Medical Board License">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Expiry Date</label>',
            '  <input type="date" class="form-control form-control-sm" id="certExpiryInput">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="certRegisterBtn">Register</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const registerBtn = document.getElementById('certRegisterBtn');
        if (registerBtn) {
            registerBtn.addEventListener('click', function () {
                const name = (document.getElementById('certNameInput').value || '').trim();
                const type = (document.getElementById('certTypeInput').value || '').trim();
                const expiry = (document.getElementById('certExpiryInput').value || '').trim();
                if (!name || !type || !expiry) {
                    return;
                }

                let certs = getCertifications();
                certs.unshift({
                    id: 'LIC-' + Math.floor(1000 + Math.random() * 9000),
                    name: name,
                    type: type,
                    issued: new Date().toISOString().split('T')[0],
                    expiry: expiry,
                    status: new Date(expiry) > new Date() ? 'Active' : 'Expired'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(certs));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderCertifications(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showCertificationsInfo('License Registered', type + ' has been registered for ' + name + '.');
            });
        }

        modal.show();
    };
})();