/**
 * Document Submission Submodule
 * Handles Digital Onboarding Files & Integration
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrDocumentSubmissions';
    const CONTRACT_KEY = 'hospitalHrContracts'; // Integration Key

    // Helper: Initialize or fetch data
    const getDocs = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        return [
            { id: "DOC-001", name: "Dr. Aris Thorne", type: "PRC License", status: "Verified", date: "2026-03-01" },
            { id: "DOC-002", name: "Sarah Jenkins", type: "PHTLS Certification", status: "Pending", date: "-" },
            { id: "DOC-003", name: "Sarah Jenkins", type: "Drug Test Result", status: "Uploaded", date: "2026-03-04" }
        ];
    };

    function ensureDocumentModalHost() {
        if (document.getElementById('documentSubmissionModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="documentSubmissionModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="documentSubmissionModalTitle">Document Submission</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="documentSubmissionModalBody"></div>',
            '      <div class="modal-footer" id="documentSubmissionModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showDocumentInfo(title, message) {
        const modalEl = document.getElementById('documentSubmissionModal');
        const titleEl = document.getElementById('documentSubmissionModalTitle');
        const bodyEl = document.getElementById('documentSubmissionModalBody');
        const footerEl = document.getElementById('documentSubmissionModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderDocumentSubmission = function (container) {
        ensureDocumentModalHost();

        const docs = getDocs();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-header-container d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div class="header-info">
                        <h6 class="fw-bold mb-0 text-dark">Document Repository</h6>
                        <small class="text-muted">Digital verification of professional credentials</small>
                    </div>
                    <button class="btn btn-sm btn-primary px-3 shadow-sm" onclick="window.HRSubmodules.triggerFileUpload()">
                        <i class="fas fa-upload me-2"></i>Upload New
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-doc-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 30%">Candidate / Staff</th>
                                <th style="width: 25%">Document Type</th>
                                <th style="width: 20%">Status</th>
                                <th class="text-end pe-4" style="width: 25%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${docs.map(doc => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark text-truncate">${doc.name}</div>
                                        <div class="text-muted extra-small">ID: ${doc.id}</div>
                                    </td>
                                    <td>
                                        <div class="text-secondary fw-medium">${doc.type}</div>
                                    </td>
                                    <td>
                                        <span class="status-indicator ${doc.status.toLowerCase()}">
                                            ${doc.status}
                                        </span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="d-flex justify-content-end gap-2">
                                            ${doc.status === 'Pending' ? 
                                                `<button class="btn btn-xs btn-outline-primary" onclick="window.HRSubmodules.updateDocStatus('${doc.id}', 'Uploaded')">Upload</button>` : 
                                                (doc.status === 'Uploaded' ? 
                                                    `<button class="btn btn-xs btn-success" onclick="window.HRSubmodules.updateDocStatus('${doc.id}', 'Verified')">Verify</button>` :
                                                    `<span class="text-muted small">${doc.date}</span>`
                                                )
                                            }
                                            <button class="btn btn-link btn-sm p-0 text-decoration-none" title="View File" onclick="window.HRSubmodules.viewDocument('${doc.id}')">
                                                <i class="fas fa-eye text-muted ms-2"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateDocStatus = function(id, newStatus) {
        let docs = getDocs();
        const idx = docs.findIndex(d => d.id === id);
        
        if (idx !== -1) {
            docs[idx].status = newStatus;
            docs[idx].date = new Date().toISOString().split('T')[0];
            localStorage.setItem(STORAGE_KEY, JSON.stringify(docs));

            // INTEGRATION LOGIC:
            // If the document is marked 'Verified', we trigger the Contract phase
            if (newStatus === 'Verified') {
                this.triggerContractWorkflow(docs[idx]);
            }

            // Sync with Dashboard
            window.dispatchEvent(new Event('storage'));
            this.renderDocumentSubmission(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.triggerContractWorkflow = function(docEntry) {
        let contracts = JSON.parse(localStorage.getItem(CONTRACT_KEY)) || [];
        
        // Prevent duplicate contracts for the same person
        const exists = contracts.find(c => c.name === docEntry.name);
        
        if (!exists) {
            contracts.unshift({
                id: "CON-" + Math.floor(1000 + Math.random() * 9000),
                name: docEntry.name,
                type: "Employment Agreement",
                status: "Drafting",
                date: new Date().toLocaleDateString()
            });
            localStorage.setItem(CONTRACT_KEY, JSON.stringify(contracts));
            console.log("Integration: Contract Drafted for " + docEntry.name);
        }
    };

    window.HRSubmodules.triggerFileUpload = function() {
        const modalEl = document.getElementById('documentSubmissionModal');
        const titleEl = document.getElementById('documentSubmissionModalTitle');
        const bodyEl = document.getElementById('documentSubmissionModalBody');
        const footerEl = document.getElementById('documentSubmissionModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Upload New Document';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="docUploadName" placeholder="e.g. Sarah Jenkins">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Document Type</label>',
            '  <input type="text" class="form-control form-control-sm" id="docUploadType" placeholder="e.g. PRC License">',
            '</div>'
        ].join('');

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="docUploadConfirm">Add Document</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const confirmBtn = document.getElementById('docUploadConfirm');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function () {
                const name = (document.getElementById('docUploadName').value || '').trim();
                const type = (document.getElementById('docUploadType').value || '').trim();
                if (!name || !type) {
                    return;
                }

                let docs = getDocs();
                docs.unshift({
                    id: 'DOC-' + Math.floor(1000 + Math.random() * 9000),
                    name: name,
                    type: type,
                    status: 'Pending',
                    date: '-'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(docs));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderDocumentSubmission(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showDocumentInfo('Document Logged', type + ' for ' + name + ' has been added to the repository.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.viewDocument = function(id) {
        const docs = getDocs();
        const target = docs.find(function (item) {
            return item.id === id;
        });

        if (!target) {
            return;
        }

        showDocumentInfo('Document Preview', target.type + ' for ' + target.name + ' is currently marked as ' + target.status + '.');
    };

})();