/**
 * Pre-Employment Requirements Submodule
 * Professional Onboarding & Compliance Checklist
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const CANDIDATE_KEY = 'hrCandidates';

    // Internal Helper: Get only those marked as 'Hired' or 'Approved'
    const getOnboardingQueue = () => {
        const stored = localStorage.getItem(CANDIDATE_KEY);
        const all = stored ? JSON.parse(stored) : [];
        return all.filter(c => c.stage === 'Hired' || c.stage === 'Approved');
    };

    function ensurePreEmploymentModal() {
        if (document.getElementById('preEmploymentModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="preEmploymentModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="preEmploymentModalTitle">Onboarding Status</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="preEmploymentModalBody"></div>',
            '      <div class="modal-footer">',
            '        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>',
            '      </div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showPreEmploymentModal(title, message) {
        const modalEl = document.getElementById('preEmploymentModal');
        const titleEl = document.getElementById('preEmploymentModalTitle');
        const bodyEl = document.getElementById('preEmploymentModalBody');

        if (!modalEl || !titleEl || !bodyEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderPreEmployment = function (container) {
        ensurePreEmploymentModal();

        const hired = getOnboardingQueue();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-tasks text-primary me-2"></i>Compliance Checklist</h6>
                        <p class="text-muted small mb-0">Verify mandatory documents for incoming medical personnel</p>
                    </div>
                    <div class="text-end">
                        <span class="badge bg-light text-primary border px-3">${hired.length} Total In-Progress</span>
                    </div>
                </div>

                <div class="row g-3">
                    ${hired.length > 0 ? hired.map(person => {
                        const progress = calculateProgress(person.requirements);
                        return `
                        <div class="col-xl-6">
                            <div class="compliance-card p-3 border rounded-3 bg-white h-100">
                                <div class="d-flex justify-content-between align-items-start mb-3 border-bottom pb-2">
                                    <div class="user-meta overflow-hidden">
                                        <h6 class="fw-bold mb-0 text-truncate" title="${person.name}">${person.name}</h6>
                                        <small class="text-primary fw-medium">${person.role || 'General Staff'}</small>
                                    </div>
                                    <div class="progress-pill ${progress === 100 ? 'complete' : ''}">
                                        ${progress}% Ready
                                    </div>
                                </div>

                                <div class="checklist-grid mt-2">
                                    ${renderCheckItems(person)}
                                </div>

                                <div class="mt-3 pt-2 border-top d-flex justify-content-end">
                                    <button class="btn btn-sm ${progress === 100 ? 'btn-success' : 'btn-light border'} px-4" 
                                            onclick="window.HRSubmodules.finalizeOnboarding('${person.id}')"
                                            ${progress === 100 ? '' : 'disabled'}>
                                        ${progress === 100 ? '<i class="fas fa-user-plus me-1"></i> Ready to Deploy' : 'Awaiting Docs'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    `}).join('') : `
                        <div class="col-12 text-center py-5 bg-white border rounded-3">
                            <h6 class="text-muted">No candidates currently in the onboarding queue.</h6>
                        </div>
                    `}
                </div>
            </div>
        `;
    };

    function renderCheckItems(person) {
        const reqs = person.requirements || { medical: false, nbi: false, contract: false, diploma: false };
        const items = [
            { key: 'medical', label: 'Medical Clearance' },
            { key: 'nbi', label: 'NBI / Police Clearance' },
            { key: 'contract', label: 'Signed Contract' },
            { key: 'diploma', label: 'Academic Credentials' }
        ];

        return items.map(item => `
            <div class="form-check mb-1">
                <input class="form-check-input" type="checkbox" 
                       id="${item.key}-${person.id}" 
                       ${reqs[item.key] ? 'checked' : ''} 
                       onchange="window.HRSubmodules.updateReqStatus('${person.id}', '${item.key}')">
                <label class="form-check-label small text-dark ms-1" for="${item.key}-${person.id}">
                    ${item.label}
                </label>
            </div>
        `).join('');
    }

    function calculateProgress(reqs) {
        if (!reqs) return 0;
        const total = Object.keys(reqs).length;
        const done = Object.values(reqs).filter(v => v === true).length;
        return Math.round((done / total) * 100);
    }

    window.HRSubmodules.updateReqStatus = function(id, key) {
        let candidates = JSON.parse(localStorage.getItem(CANDIDATE_KEY)) || [];
        const idx = candidates.findIndex(c => c.id === id);
        
        if (idx !== -1) {
            if (!candidates[idx].requirements) {
                candidates[idx].requirements = { medical: false, nbi: false, contract: false, diploma: false };
            }
            candidates[idx].requirements[key] = !candidates[idx].requirements[key];
            
            localStorage.setItem(CANDIDATE_KEY, JSON.stringify(candidates));
            // Trigger local re-render
            this.renderPreEmployment(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.finalizeOnboarding = function(id) {
        const candidates = JSON.parse(localStorage.getItem(CANDIDATE_KEY)) || [];
        const target = candidates.find(function (candidate) {
            return candidate.id === id;
        });

        const personName = target ? target.name : 'Selected candidate';
        showPreEmploymentModal('Deployment Ready', personName + ' is now cleared for hospital duties. Deployment protocols have been initiated.');
        // Future logic for Dashboard integration goes here
    };

})();