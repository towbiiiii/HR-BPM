window.HRSubmodules = window.HRSubmodules || {};

function ensurePersonalInfoModalHost() {
    if (document.getElementById('updatePersonalInfoModal')) {
        return;
    }

    const modalHost = document.createElement('div');
    modalHost.innerHTML = [
        '<div class="modal fade" id="updatePersonalInfoModal" tabindex="-1" aria-hidden="true">',
        '  <div class="modal-dialog modal-dialog-centered">',
        '    <div class="modal-content">',
        '      <div class="modal-header">',
        '        <h5 class="modal-title" id="updatePersonalInfoModalTitle">Update Personal Info</h5>',
        '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
        '      </div>',
        '      <div class="modal-body" id="updatePersonalInfoModalBody"></div>',
        '      <div class="modal-footer" id="updatePersonalInfoModalFooter"></div>',
        '    </div>',
        '  </div>',
        '</div>'
    ].join('');

    document.body.appendChild(modalHost.firstElementChild);
}

function showPersonalInfoSavedModal(name) {
    const modalEl = document.getElementById('updatePersonalInfoModal');
    const titleEl = document.getElementById('updatePersonalInfoModalTitle');
    const bodyEl = document.getElementById('updatePersonalInfoModalBody');
    const footerEl = document.getElementById('updatePersonalInfoModalFooter');
    if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
        return;
    }

    titleEl.textContent = 'Profile Updated';
    bodyEl.innerHTML = '<p class="mb-0">Changes for ' + name + ' were saved successfully.</p>';
    footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">View Profile</button>';

    modalEl.addEventListener('hidden.bs.modal', function handleClose() {
        modalEl.removeEventListener('hidden.bs.modal', handleClose);
        if (typeof renderInlineSubmoduleContent === 'function') {
            renderInlineSubmoduleContent('View Profile');
        }
    });

    window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
}

window.HRSubmodules.renderUpdatePersonalInfo = function (container) {
    ensurePersonalInfoModalHost();

    const employees = JSON.parse(localStorage.getItem('hospitalHrHcmEmployees') || '[]');
    const employeeId = localStorage.getItem('hospitalHrEmployeeId') || "EMP-2024-001";
    
    // Find existing data or provide defaults
    const user = employees.find(e => e.id === employeeId) || {
        name: "Alex Rivera",
        role: "Senior Clinical Lead",
        dept: "Medical Operations"
    };

    container.innerHTML = `
        <div class="settings-card animate-fade-in">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-bottom py-3">
                    <h6 class="mb-0 fw-bold"><i class="bi bi-person-gear me-2"></i>Account Settings</h6>
                </div>
                <div class="card-body p-4">
                    <form id="update-info-form">
                        <div class="row g-4">
                            <div class="col-12 d-flex align-items-center mb-2">
                                <div class="position-relative">
                                    <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=0D6EFD&color=fff&size=64" class="rounded-circle me-3" id="form-avatar">
                                </div>
                                <div>
                                    <h6 class="mb-0">Profile Photo</h6>
                                    <p class="text-muted small mb-0">Avatar updates automatically based on name.</p>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-uppercase">Full Name</label>
                                <input type="text" class="form-control bg-light border-0 py-2" id="input-name" value="${user.name}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-uppercase">Department</label>
                                <select class="form-select bg-light border-0 py-2" id="input-dept">
                                    <option ${user.dept === 'Medical Operations' ? 'selected' : ''}>Medical Operations</option>
                                    <option ${user.dept === 'Administration' ? 'selected' : ''}>Administration</option>
                                    <option ${user.dept === 'Emergency' ? 'selected' : ''}>Emergency</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-uppercase">Professional Title</label>
                                <input type="text" class="form-control bg-light border-0 py-2" id="input-role" value="${user.role}">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-uppercase">Phone Number</label>
                                <input type="tel" class="form-control bg-light border-0 py-2" placeholder="+1 (555) 000-0000">
                            </div>

                            <div class="col-12 mt-4 pt-3 border-top d-flex justify-content-end gap-2">
                                <button type="button" class="btn btn-link text-muted text-decoration-none btn-sm" onclick="renderInlineSubmoduleContent('View Profile')">Cancel</button>
                                <button type="submit" class="btn btn-primary px-4 py-2 shadow-sm">Save Changes</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;

    const form = document.getElementById('update-info-form');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const updatedUser = {
            id: employeeId,
            name: document.getElementById('input-name').value,
            role: document.getElementById('input-role').value,
            dept: document.getElementById('input-dept').value,
            status: "Active",
            joined: user.joined || "Jan 2024"
        };

        // Update the array
        const index = employees.findIndex(e => e.id === employeeId);
        if (index > -1) {
            employees[index] = updatedUser;
        } else {
            employees.push(updatedUser);
        }

        // Save and Trigger Global Sync
        localStorage.setItem('hospitalHrHcmEmployees', JSON.stringify(employees));

        // Re-initialize dashboard and confirm save through modal feedback.
        if (typeof initRoleDashboard === 'function') {
            initRoleDashboard();
        }
        showPersonalInfoSavedModal(updatedUser.name);
    });
};