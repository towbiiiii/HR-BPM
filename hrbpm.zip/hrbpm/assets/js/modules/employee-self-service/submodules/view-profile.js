window.HRSubmodules = window.HRSubmodules || {};

function ensureViewProfileModalHost() {
    if (document.getElementById('viewProfileModal')) {
        return;
    }

    const modalHost = document.createElement('div');
    modalHost.innerHTML = [
        '<div class="modal fade" id="viewProfileModal" tabindex="-1" aria-hidden="true">',
        '  <div class="modal-dialog modal-dialog-centered">',
        '    <div class="modal-content">',
        '      <div class="modal-header">',
        '        <h5 class="modal-title" id="viewProfileModalTitle">Employee Profile</h5>',
        '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
        '      </div>',
        '      <div class="modal-body" id="viewProfileModalBody"></div>',
        '      <div class="modal-footer" id="viewProfileModalFooter"></div>',
        '    </div>',
        '  </div>',
        '</div>'
    ].join('');

    document.body.appendChild(modalHost.firstElementChild);
}

function showViewProfileInfo(title, message) {
    const modalEl = document.getElementById('viewProfileModal');
    const titleEl = document.getElementById('viewProfileModalTitle');
    const bodyEl = document.getElementById('viewProfileModalBody');
    const footerEl = document.getElementById('viewProfileModalFooter');
    if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
        return;
    }

    titleEl.textContent = title;
    bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
    footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
    window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
}

window.HRSubmodules.renderViewProfile = function (container) {
    ensureViewProfileModalHost();

    // 1. Fetch real data from the keys identified in main.js
    const employees = JSON.parse(localStorage.getItem('hospitalHrHcmEmployees') || '[]');
    const licenses = JSON.parse(localStorage.getItem('hospitalHrLicenseVault') || '[]');
    const employeeId = localStorage.getItem('hospitalHrEmployeeId') || "EMP-2024-001";
    
    // Find current user or fallback to a template
    const user = employees.find(e => e.id === employeeId) || {
        name: "Alex Rivera",
        role: "Senior Clinical Lead",
        dept: "Medical Operations",
        joined: "Jan 2022",
        status: "Active"
    };

    container.innerHTML = `
        <div class="profile-wrapper animate-fade-in">
            <div class="row g-4 mb-4">
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm text-center p-4">
                        <div class="position-relative d-inline-block mx-auto mb-3">
                            <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=0D6EFD&color=fff&size=128" 
                                 class="rounded-circle border border-4 border-white shadow-sm" alt="Profile">
                            <span class="position-absolute bottom-0 end-0 bg-success border border-2 border-white rounded-circle p-2" title="Online"></span>
                        </div>
                        <h4 class="fw-bold mb-1">${user.name}</h4>
                        <p class="text-muted small mb-3">${user.role} | ${user.dept}</p>
                        <div class="d-flex justify-content-center gap-2">
                            <button class="btn btn-sm btn-primary px-3" onclick="window.HRSubmodules.openProfileMessenger('${user.name.replace(/'/g, "\\'")}')">Message</button>
                            <button class="btn btn-sm btn-outline-secondary px-3" onclick="window.HRSubmodules.openEditProfilePrompt()">Edit Profile</button>
                        </div>
                    </div>
                </div>

                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white py-3">
                            <h6 class="mb-0 fw-bold">Employment Details</h6>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-sm-6">
                                    <label class="extra-small d-block mb-1">Employee ID</label>
                                    <p class="fw-medium mb-0">${employeeId}</p>
                                </div>
                                <div class="col-sm-6">
                                    <label class="extra-small d-block mb-1">Work Email</label>
                                    <p class="fw-medium mb-0">${user.name.toLowerCase().replace(' ', '.')}@hospital.org</p>
                                </div>
                                <div class="col-sm-6">
                                    <label class="extra-small d-block mb-1">Join Date</label>
                                    <p class="fw-medium mb-0">${user.joined || 'N/A'}</p>
                                </div>
                                <div class="col-sm-6">
                                    <label class="extra-small d-block mb-1">Status</label>
                                    <span class="badge bg-success-subtle text-success">${user.status}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                            <h6 class="mb-0 fw-bold">Professional Licenses</h6>
                            <span class="badge bg-primary-subtle text-primary">${licenses.length} Total</span>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <th class="ps-3">Credential</th>
                                            <th>Expiry</th>
                                            <th class="pe-3">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${licenses.length > 0 ? licenses.map(l => `
                                            <tr>
                                                <td class="ps-3"><span class="fw-medium">${l.type}</span></td>
                                                <td>${l.expiryDate}</td>
                                                <td class="pe-3"><span class="badge ${l.status === 'Expired' ? 'bg-danger' : 'bg-success'}">${l.status}</span></td>
                                            </tr>
                                        `).join('') : '<tr><td colspan="3" class="text-center py-4 text-muted small">No licenses on record</td></tr>'}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white py-3">
                            <h6 class="mb-0 fw-bold">Core Competencies</h6>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <div class="d-flex justify-content-between mb-1">
                                    <span class="small fw-medium">Clinical Excellence</span>
                                    <span class="extra-small">90%</span>
                                </div>
                                <div class="progress" style="height: 6px;">
                                    <div class="progress-bar bg-primary" style="width: 90%"></div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between mb-1">
                                    <span class="small fw-medium">Administrative Leadership</span>
                                    <span class="extra-small">75%</span>
                                </div>
                                <div class="progress" style="height: 6px;">
                                    <div class="progress-bar bg-info" style="width: 75%"></div>
                                </div>
                            </div>
                            <div class="mb-0">
                                <div class="d-flex justify-content-between mb-1">
                                    <span class="small fw-medium">Compliance & Ethics</span>
                                    <span class="extra-small">100%</span>
                                </div>
                                <div class="progress" style="height: 6px;">
                                    <div class="progress-bar bg-success" style="width: 100%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
};

window.HRSubmodules.openProfileMessenger = function (name) {
    showViewProfileInfo('Messenger', 'Opening secure messenger for ' + name + '.');
};

window.HRSubmodules.openEditProfilePrompt = function () {
    const modalEl = document.getElementById('viewProfileModal');
    const titleEl = document.getElementById('viewProfileModalTitle');
    const bodyEl = document.getElementById('viewProfileModalBody');
    const footerEl = document.getElementById('viewProfileModalFooter');
    if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
        return;
    }

    titleEl.textContent = 'Edit Profile';
    bodyEl.innerHTML = '<p class="mb-0">Open the Personal Info form to update your name, department, and professional title.</p>';
    footerEl.innerHTML = [
        '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
        '<button type="button" class="btn btn-primary" id="openPersonalInfoFormBtn">Open Form</button>'
    ].join('');

    const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
    const openBtn = document.getElementById('openPersonalInfoFormBtn');
    if (openBtn) {
        openBtn.addEventListener('click', function () {
            modal.hide();
            if (typeof renderInlineSubmoduleContent === 'function') {
                renderInlineSubmoduleContent('Update Personal Info');
            }
        });
    }

    modal.show();
};