/**
 * Evaluation Results Submodule
 * Final performance reporting and history
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrEvalResults';

    const getResults = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Medical Staff Evaluation History
        return [
            { id: "RES-2026-001", name: "Dr. Aris Thorne", period: "Q1 2026", finalScore: 94, outcome: "Permanent", remark: "Exceptional clinical precision." },
            { id: "RES-2026-002", name: "Sarah Jenkins", period: "Q1 2026", finalScore: 78, outcome: "Extended", remark: "Requires more administrative focus." },
            { id: "RES-2026-003", name: "James Miller", period: "Q1 2026", finalScore: 82, outcome: "Permanent", remark: "Technical skills meet hospital standards." }
        ];
    };

    function ensureEvaluationResultsModal() {
        if (document.getElementById('evaluationResultsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="evaluationResultsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="evaluationResultsModalTitle">Evaluation Reports</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="evaluationResultsModalBody"></div>',
            '      <div class="modal-footer" id="evaluationResultsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    window.HRSubmodules.renderEvaluationResults = function (container) {
        ensureEvaluationResultsModal();

        const results = getResults();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <div class="bg-white p-3 border rounded-3 shadow-sm text-center">
                            <div class="text-muted small fw-bold text-uppercase">Avg. Hospital Score</div>
                            <h4 class="fw-bold text-primary mb-0">84.6%</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-white p-3 border rounded-3 shadow-sm text-center">
                            <div class="text-muted small fw-bold text-uppercase">Passing Rate</div>
                            <h4 class="fw-bold text-success mb-0">92%</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-white p-3 border rounded-3 shadow-sm d-flex align-items-center justify-content-center">
                            <button class="btn btn-sm btn-outline-dark" onclick="window.HRSubmodules.exportEvaluationReport()">
                                <i class="fas fa-file-pdf me-2"></i>Export Reports
                            </button>
                        </div>
                    </div>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-result-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Employee Details</th>
                                <th style="width: 15%">Review Period</th>
                                <th style="width: 15%">Final Score</th>
                                <th style="width: 15%">Outcome</th>
                                <th class="pe-4" style="width: 30%">HR Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${results.map(res => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${res.name}</div>
                                        <div class="extra-small text-muted">${res.id}</div>
                                    </td>
                                    <td class="text-secondary small">${res.period}</td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <span class="fw-bold me-2 ${res.finalScore >= 80 ? 'text-success' : 'text-warning'}">${res.finalScore}%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="outcome-pill ${res.outcome.toLowerCase()}">${res.outcome}</span>
                                    </td>
                                    <td class="pe-4">
                                        <div class="remark-text" title="${res.remark}">${res.remark}</div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.exportEvaluationReport = function () {
        const modalEl = document.getElementById('evaluationResultsModal');
        const titleEl = document.getElementById('evaluationResultsModalTitle');
        const bodyEl = document.getElementById('evaluationResultsModalBody');
        const footerEl = document.getElementById('evaluationResultsModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Export Evaluation Reports';
        bodyEl.innerHTML = '<p class="mb-0">Generate a printable copy of current evaluation results?</p>';
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="evaluationExportConfirmBtn">Export</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const exportBtn = document.getElementById('evaluationExportConfirmBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', function () {
                window.print();
                modal.hide();
            });
        }

        modal.show();
    };

})();