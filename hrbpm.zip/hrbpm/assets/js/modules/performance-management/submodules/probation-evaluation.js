/**
 * Probation Evaluation Submodule
 * Handles performance review for new medical and admin staff
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrProbationEvals';

    const getEvals = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Mock Data for Probationary Period
        return [
            { id: "EVL-901", name: "Dr. Aris Thorne", role: "Resident Physician", score: 92, status: "Recommended", date: "2026-03-05" },
            { id: "EVL-902", name: "Sarah Jenkins", role: "Head Nurse", score: 45, status: "Under Review", date: "2026-03-06" },
            { id: "EVL-903", name: "James Miller", role: "Radiology Tech", score: 0, status: "Pending", date: "-" }
        ];
    };

    function ensureProbationModalHost() {
        if (document.getElementById('probationEvalModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="probationEvalModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="probationEvalModalTitle">Probation Evaluation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="probationEvalModalBody"></div>',
            '      <div class="modal-footer" id="probationEvalModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showProbationInfo(title, message) {
        const modalEl = document.getElementById('probationEvalModal');
        const titleEl = document.getElementById('probationEvalModalTitle');
        const bodyEl = document.getElementById('probationEvalModalBody');
        const footerEl = document.getElementById('probationEvalModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderProbationEvaluation = function (container) {
        ensureProbationModalHost();

        const evals = getEvals();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-clipboard-check text-primary me-2"></i>Probationary Performance</h6>
                        <small class="text-muted">Monitor and evaluate new hire progress for regularization</small>
                    </div>
                    <button class="btn btn-primary btn-sm px-3" onclick="window.HRSubmodules.addNewEvaluation()">
                        <i class="fas fa-user-plus me-1"></i> Start Evaluation
                    </button>
                </div>

                <div class="row g-3">
                    ${evals.map(evalItem => `
                        <div class="col-xl-4 col-md-6">
                            <div class="eval-card p-3 border rounded-3 bg-white h-100 shadow-sm">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h6 class="fw-bold mb-0 text-dark">${evalItem.name}</h6>
                                        <small class="text-primary">${evalItem.role}</small>
                                    </div>
                                    <span class="badge-eval ${evalItem.status.replace(/\s+/g, '-').toLowerCase()}">${evalItem.status}</span>
                                </div>

                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <span class="extra-small text-muted">Performance Score</span>
                                        <span class="extra-small fw-bold">${evalItem.score}%</span>
                                    </div>
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar ${evalItem.score >= 75 ? 'bg-success' : 'bg-warning'}" 
                                             role="progressbar" style="width: ${evalItem.score}%"></div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <span class="text-muted extra-small">Last Updated: ${evalItem.date}</span>
                                    <div class="btn-group">
                                        <button class="btn btn-xs btn-outline-secondary" onclick="window.HRSubmodules.updateScore('${evalItem.id}')">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        ${evalItem.score >= 80 && evalItem.status !== 'Recommended' ? 
                                            `<button class="btn btn-xs btn-success ms-1" onclick="window.HRSubmodules.finalizeEval('${evalItem.id}', 'Recommended')">Approve</button>` : ''
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateScore = function(id) {
        const evals = getEvals();
        const idx = evals.findIndex(function (entry) {
            return entry.id === id;
        });
        if (idx === -1) {
            return;
        }

        const target = evals[idx];
        const modalEl = document.getElementById('probationEvalModal');
        const titleEl = document.getElementById('probationEvalModalTitle');
        const bodyEl = document.getElementById('probationEvalModalBody');
        const footerEl = document.getElementById('probationEvalModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Update Performance Score';
        bodyEl.innerHTML = [
            '<p class="mb-2">Update score for <strong>' + target.name + '</strong>.</p>',
            '<label class="form-label small mb-1">Score (0-100)</label>',
            '<input type="number" min="0" max="100" class="form-control form-control-sm" id="probationScoreInput" value="' + target.score + '">'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="probationScoreSaveBtn">Save</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('probationScoreSaveBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const rawScore = Number(document.getElementById('probationScoreInput').value);
                if (Number.isNaN(rawScore) || rawScore < 0 || rawScore > 100) {
                    return;
                }

                evals[idx].score = Math.round(rawScore);
                evals[idx].status = evals[idx].score >= 75 ? 'Under Review' : 'Pending';
                evals[idx].date = new Date().toLocaleDateString();
                localStorage.setItem(STORAGE_KEY, JSON.stringify(evals));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderProbationEvaluation(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.finalizeEval = function(id, status) {
        let evals = getEvals();
        const idx = evals.findIndex(e => e.id === id);
        if (idx !== -1) {
            const target = evals[idx];
            const modalEl = document.getElementById('probationEvalModal');
            const titleEl = document.getElementById('probationEvalModalTitle');
            const bodyEl = document.getElementById('probationEvalModalBody');
            const footerEl = document.getElementById('probationEvalModalFooter');

            if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
                return;
            }

            titleEl.textContent = 'Finalize Evaluation';
            bodyEl.innerHTML = '<p class="mb-0">Mark <strong>' + target.name + '</strong> as ' + status + '?</p>';
            footerEl.innerHTML = [
                '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                '<button type="button" class="btn btn-success" id="probationFinalizeBtn">Confirm</button>'
            ].join('');

            const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
            const finalizeBtn = document.getElementById('probationFinalizeBtn');
            if (finalizeBtn) {
                finalizeBtn.addEventListener('click', function () {
                    evals[idx].status = status;
                    evals[idx].date = new Date().toLocaleDateString();
                    localStorage.setItem(STORAGE_KEY, JSON.stringify(evals));
                    window.dispatchEvent(new Event('storage'));
                    window.HRSubmodules.renderProbationEvaluation(document.getElementById('roleModuleOverviewBody'));
                    modal.hide();
                    showProbationInfo('Evaluation Finalized', target.name + ' has been marked as ' + status + '.');
                });
            }

            modal.show();
        }
    };

    window.HRSubmodules.addNewEvaluation = function() {
        const modalEl = document.getElementById('probationEvalModal');
        const titleEl = document.getElementById('probationEvalModalTitle');
        const bodyEl = document.getElementById('probationEvalModalBody');
        const footerEl = document.getElementById('probationEvalModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Start New Evaluation';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Employee Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="probationNewName" placeholder="e.g. Alex Rivera">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Role</label>',
            '  <input type="text" class="form-control form-control-sm" id="probationNewRole" placeholder="e.g. Staff Nurse">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="probationCreateBtn">Create</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('probationCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('probationNewName').value || '').trim();
                const role = (document.getElementById('probationNewRole').value || '').trim() || 'General Staff';
                if (!name) {
                    return;
                }

                const evals = getEvals();
                evals.unshift({
                    id: 'EVL-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    role: role,
                    score: 0,
                    status: 'Pending',
                    date: '-'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(evals));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderProbationEvaluation(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

})();