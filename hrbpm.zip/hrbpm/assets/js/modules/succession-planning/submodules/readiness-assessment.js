// Ensure this is accessible to the renderInlineSubmoduleContent function in main.js
window.HRSubmodules = window.HRSubmodules || {};

function ensureReadinessAssessmentModalHost() {
    if (document.getElementById('readinessAssessmentModal')) {
        return;
    }

    const modalHost = document.createElement('div');
    modalHost.innerHTML = [
        '<div class="modal fade" id="readinessAssessmentModal" tabindex="-1" aria-hidden="true">',
        '  <div class="modal-dialog modal-dialog-centered">',
        '    <div class="modal-content">',
        '      <div class="modal-header">',
        '        <h5 class="modal-title" id="readinessAssessmentModalTitle">Readiness Assessment</h5>',
        '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
        '      </div>',
        '      <div class="modal-body" id="readinessAssessmentModalBody"></div>',
        '      <div class="modal-footer" id="readinessAssessmentModalFooter"></div>',
        '    </div>',
        '  </div>',
        '</div>'
    ].join('');

    document.body.appendChild(modalHost.firstElementChild);
}

function showReadinessAssessmentInfo(title, message) {
    const modalEl = document.getElementById('readinessAssessmentModal');
    const titleEl = document.getElementById('readinessAssessmentModalTitle');
    const bodyEl = document.getElementById('readinessAssessmentModalBody');
    const footerEl = document.getElementById('readinessAssessmentModalFooter');
    if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
        return;
    }

    titleEl.textContent = title;
    bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
    footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
    window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
}

window.HRSubmodules.renderReadinessAssessment = function (container) {
    ensureReadinessAssessmentModalHost();

    const questions = [
        { id: 1, text: "Candidate demonstrates core technical competency for the target role.", category: "Technical" },
        { id: 2, text: "Candidate has completed all required leadership training modules.", category: "Training" },
        { id: 3, text: "Performance reviews consistently meet or exceed 'Exceeds Expectations'.", category: "Performance" },
        { id: 4, text: "Candidate has successfully mentored at least two junior staff members.", category: "Leadership" }
    ];

    container.innerHTML = `
        <div class="card border-0 shadow-sm animate-fade-in">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h5 class="mb-1">Succession Readiness Tool</h5>
                        <p class="text-muted small mb-0">Evaluate internal candidates for critical position transition.</p>
                    </div>
                    <div class="text-end">
                        <span class="badge bg-primary px-3 py-2" id="live-score">Readiness: 0%</span>
                    </div>
                </div>

                <form id="assessment-form">
                    <div class="mb-4">
                        <label class="form-label fw-bold small text-uppercase">Select Candidate</label>
                        <select class="form-select border-light-subtle" id="candidate-select" required>
                            <option value="">Choose an employee...</option>
                            <option value="EMP-2024-001">John Doe (Senior Surgeon)</option>
                            <option value="EMP-2024-012">Jane Smith (Head Nurse)</option>
                        </select>
                    </div>

                    <div class="assessment-questions">
                        ${questions.map(q => `
                            <div class="question-row p-3 mb-2 rounded border border-light-subtle bg-white">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <span class="badge bg-light text-dark extra-small mb-1">${q.category}</span>
                                        <p class="mb-0 small fw-medium">${q.text}</p>
                                    </div>
                                    <div class="col-md-4 text-md-end mt-2 mt-md-0">
                                        <div class="btn-group btn-group-sm" role="group">
                                            <input type="radio" class="btn-check" name="q${q.id}" id="q${q.id}y" value="25" autocomplete="off">
                                            <label class="btn btn-outline-success" for="q${q.id}y">Met</label>
                                            
                                            <input type="radio" class="btn-check" name="q${q.id}" id="q${q.id}n" value="0" autocomplete="off" checked>
                                            <label class="btn btn-outline-secondary" for="q${q.id}n">Not Met</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>

                    <div class="mt-4 pt-3 border-top d-flex justify-content-between align-items-center">
                        <button type="button" class="btn btn-light btn-sm text-muted" id="reset-assessment">Reset</button>
                        <button type="submit" class="btn btn-primary px-4">Submit Assessment</button>
                    </div>
                </form>
            </div>
        </div>
    `;

    // Real-time score calculation as they click
    const form = document.getElementById('assessment-form');
    form.addEventListener('change', () => {
        const data = new FormData(form);
        let score = 0;
        for (let value of data.values()) { score += parseInt(value); }
        document.getElementById('live-score').innerText = `Readiness: ${score}%`;
    });

    // Save to LocalStorage to trigger main.js updateDashboardFromModuleData()
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const candidate = document.getElementById('candidate-select').value;
        const data = new FormData(form);
        let score = 0;
        for (let value of data.values()) { score += parseInt(value); }

        const readinessEntries = JSON.parse(localStorage.getItem('hospitalHrReadiness') || '[]');
        readinessEntries.push({
            id: Date.now(),
            candidate: candidate,
            score: score,
            status: score >= 75 ? 'Ready' : 'Developing',
            date: new Date().toLocaleDateString()
        });

        localStorage.setItem('hospitalHrReadiness', JSON.stringify(readinessEntries));
        showReadinessAssessmentInfo('Assessment Synced', 'Dashboard metrics were updated successfully.');
        renderInlineSubmoduleContent('Readiness Assessment'); // Refresh view
    });
};