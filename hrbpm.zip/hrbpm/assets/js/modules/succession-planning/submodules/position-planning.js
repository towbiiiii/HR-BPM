/**
 * Position Planning Submodule
 * Professional Strategic Succession Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrPositionPlanning';

    const getPositions = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Baseline Professional Position Data
        return [
            { id: "POS-101", title: "Chief Nursing Officer", department: "Nursing Admin", risk: "High", bench: 2, status: "Critical" },
            { id: "POS-102", title: "Head of Radiology", department: "Diagnostic", risk: "Medium", bench: 3, status: "Stable" },
            { id: "POS-103", title: "IT Infrastructure Director", department: "IT", risk: "High", bench: 1, status: "Vulnerable" }
        ];
    };

    function ensurePositionPlanningModalHost() {
        if (document.getElementById('positionPlanningModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="positionPlanningModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="positionPlanningModalTitle">Position Planning</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="positionPlanningModalBody"></div>',
            '      <div class="modal-footer" id="positionPlanningModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showPositionPlanningInfo(title, message) {
        const modalEl = document.getElementById('positionPlanningModal');
        const titleEl = document.getElementById('positionPlanningModalTitle');
        const bodyEl = document.getElementById('positionPlanningModalBody');
        const footerEl = document.getElementById('positionPlanningModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderPositionPlanning = function (container) {
        ensurePositionPlanningModalHost();

        const positions = getPositions();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-sitemap text-primary me-2"></i>Position & Bench Strength Planning</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Succession Strategy for Critical Roles</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.addNewPositionPlan()">
                        <i class="fas fa-plus-circle me-1"></i> Add Position Plan
                    </button>
                </div>

                <div class="row g-4">
                    ${positions.map(pos => `
                        <div class="col-xl-4 col-md-6">
                            <div class="position-card border rounded-4 bg-white shadow-sm h-100 overflow-hidden">
                                <div class="p-4">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div>
                                            <h6 class="fw-bold text-dark mb-1">${pos.title}</h6>
                                            <span class="badge bg-light text-muted border extra-small">${pos.department}</span>
                                        </div>
                                        <span class="status-indicator ${pos.status.toLowerCase()}">${pos.status}</span>
                                    </div>
                                    
                                    <div class="planning-stats border-top pt-3 mt-3">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="text-muted extra-small text-uppercase fw-bold">Departure Risk</div>
                                                <div class="fw-bold ${pos.risk === 'High' ? 'text-danger' : 'text-warning'}">${pos.risk}</div>
                                            </div>
                                            <div class="col-6 border-start">
                                                <div class="text-muted extra-small text-uppercase fw-bold">Successors</div>
                                                <div class="fw-bold text-primary">${pos.bench} Ready</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mt-4 d-grid gap-2">
                                        <button class="btn btn-outline-primary btn-sm" onclick="window.HRSubmodules.managePositionBench('${pos.id}')">
                                            <i class="fas fa-users-viewfinder me-1"></i> Manage Bench
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.addNewPositionPlan = function() {
        const modalEl = document.getElementById('positionPlanningModal');
        const titleEl = document.getElementById('positionPlanningModalTitle');
        const bodyEl = document.getElementById('positionPlanningModalBody');
        const footerEl = document.getElementById('positionPlanningModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Add Position Plan';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Position Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="positionPlanTitle" placeholder="e.g. Head of Radiology">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Department</label>',
            '  <input type="text" class="form-control form-control-sm" id="positionPlanDepartment" placeholder="e.g. Diagnostic">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Risk Level</label>',
            '  <select class="form-select form-select-sm" id="positionPlanRisk">',
            '    <option value="Medium">Medium</option>',
            '    <option value="High">High</option>',
            '    <option value="Low">Low</option>',
            '  </select>',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="savePositionPlanBtn">Save</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('savePositionPlanBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const title = (document.getElementById('positionPlanTitle').value || '').trim();
                const dept = (document.getElementById('positionPlanDepartment').value || '').trim();
                const risk = (document.getElementById('positionPlanRisk').value || '').trim() || 'Medium';
                if (!title || !dept) {
                    return;
                }

                let positions = getPositions();
                positions.unshift({
                    id: 'POS-' + Math.floor(100 + Math.random() * 900),
                    title: title,
                    department: dept,
                    risk: risk,
                    bench: 0,
                    status: 'Review Required'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(positions));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderPositionPlanning(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showPositionPlanningInfo('Plan Added', title + ' was added to succession position planning.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.managePositionBench = function (positionId) {
        const positions = getPositions();
        const target = positions.find(function (pos) { return pos.id === positionId; });
        if (!target) {
            return;
        }

        showPositionPlanningInfo('Manage Bench', 'Potential successors for ' + target.title + ' (' + target.department + ') are ready to review.');
    };
})();