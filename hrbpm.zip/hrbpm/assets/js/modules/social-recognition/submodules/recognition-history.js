/**
 * Recognition History Submodule
 * Comprehensive Archive of Staff Achievements
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrRecognitions';

    const getHistory = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    };

    function ensureRecognitionHistoryModal() {
        if (document.getElementById('recognitionHistoryModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="recognitionHistoryModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="recognitionHistoryModalTitle">Recognition Record</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="recognitionHistoryModalBody"></div>',
            '      <div class="modal-footer">',
            '        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>',
            '      </div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function attachRecognitionHistoryInteractions(history) {
        const searchInput = document.getElementById('historySearch');
        if (searchInput) {
            searchInput.addEventListener('input', function () {
                const term = (searchInput.value || '').trim().toLowerCase();
                document.querySelectorAll('.timeline-item').forEach(function (itemEl) {
                    const haystack = (itemEl.textContent || '').toLowerCase();
                    itemEl.style.display = haystack.indexOf(term) !== -1 ? '' : 'none';
                });
            });
        }

        document.querySelectorAll('.timeline-content-col').forEach(function (cardEl) {
            cardEl.addEventListener('click', function () {
                const itemId = cardEl.getAttribute('data-id');
                const target = history.find(function (entry) {
                    return entry.id === itemId;
                });
                if (!target) {
                    return;
                }

                const modalEl = document.getElementById('recognitionHistoryModal');
                const titleEl = document.getElementById('recognitionHistoryModalTitle');
                const bodyEl = document.getElementById('recognitionHistoryModalBody');
                if (!modalEl || !titleEl || !bodyEl || !(window.bootstrap && window.bootstrap.Modal)) {
                    return;
                }

                titleEl.textContent = target.award;
                bodyEl.innerHTML = [
                    '<p class="mb-1"><strong>Recipient:</strong> ' + target.name + '</p>',
                    '<p class="mb-1"><strong>Reference ID:</strong> ' + target.id + '</p>',
                    '<p class="mb-0"><strong>Date Awarded:</strong> ' + target.date + '</p>'
                ].join('');
                window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
            });
        });
    }

    window.HRSubmodules.renderRecognitionHistory = function (container) {
        ensureRecognitionHistoryModal();

        const history = getHistory();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-history text-info me-2"></i>Achievement Archive</h6>
                        <small class="text-muted">Historical log of all departmental and institutional awards</small>
                    </div>
                    <div class="search-box-sm">
                        <input type="text" class="form-control form-control-sm" placeholder="Search recipient..." id="historySearch">
                    </div>
                </div>

                ${history.length === 0 ? `
                    <div class="text-center p-5 bg-white border rounded-3">
                        <i class="fas fa-folder-open fa-3x text-light mb-3"></i>
                        <p class="text-muted">No historical records found.</p>
                    </div>
                ` : `
                    <div class="timeline-container">
                        ${history.map((item, index) => `
                            <div class="timeline-item d-flex mb-4">
                                <div class="timeline-date-col text-end pe-4 pt-1">
                                    <div class="fw-bold text-dark small">${item.date}</div>
                                    <div class="extra-small text-muted">Ref: ${item.id}</div>
                                </div>
                                <div class="timeline-marker-col position-relative px-3">
                                    <div class="timeline-line"></div>
                                    <div class="timeline-dot" style="background-color: ${item.color || '#0d6efd'}"></div>
                                </div>
                                <div class="timeline-content-col flex-grow-1 bg-white p-3 border rounded-3 shadow-sm" data-id="${item.id}" style="cursor: pointer;">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold text-primary mb-1">${item.award}</h6>
                                        <i class="fas fa-medal text-warning"></i>
                                    </div>
                                    <div class="text-dark fw-medium mb-1">${item.name}</div>
                                    <p class="text-muted extra-small mb-0">Officially recorded in the Institutional Merit Registry.</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                `}
            </div>
        `;

        attachRecognitionHistoryInteractions(history);
    };

})();