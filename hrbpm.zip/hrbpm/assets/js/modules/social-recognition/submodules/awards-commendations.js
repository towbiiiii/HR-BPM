/**
 * Awards & Commendations Submodule
 * Official Hospital Registry for Career Milestones
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCommendations';

    const getCommendations = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Medical Commendation Records
        return [
            { id: "CERT-2026-001", name: "Dr. Aris Thorne", title: "DOH Outstanding Physician", level: "National", date: "2026-01-15" },
            { id: "CERT-2026-002", name: "Sarah Jenkins", title: "Patient Safety Advocate Award", level: "Institutional", date: "2026-02-10" }
        ];
    };

    function ensureCommendationModalHost() {
        if (document.getElementById('awardsCommendationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="awardsCommendationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="awardsCommendationModalTitle">Awards Registry</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="awardsCommendationModalBody"></div>',
            '      <div class="modal-footer" id="awardsCommendationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showCommendationInfo(title, message) {
        const modalEl = document.getElementById('awardsCommendationModal');
        const titleEl = document.getElementById('awardsCommendationModalTitle');
        const bodyEl = document.getElementById('awardsCommendationModalBody');
        const footerEl = document.getElementById('awardsCommendationModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderAwardsCommendations = function (container) {
        ensureCommendationModalHost();

        const data = getCommendations();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-certificate text-danger me-2"></i>Awards Registry</h6>
                        <small class="text-muted text-uppercase" style="font-size: 10px; letter-spacing: 1px;">Official Records of Merit</small>
                    </div>
                    <button class="btn btn-dark btn-sm px-3 shadow-sm" onclick="window.HRSubmodules.recordNewAward()">
                        <i class="fas fa-pen-nib me-2"></i>Record Commendation
                    </button>
                </div>

                <div class="commendation-list">
                    ${data.map(item => `
                        <div class="commendation-item d-flex align-items-center bg-white p-3 mb-3 border rounded-3 shadow-sm">
                            <div class="award-seal me-4">
                                <i class="fas fa-ribbon fa-2x"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="fw-bold mb-0 text-dark">${item.title}</h6>
                                <div class="d-flex gap-3 mt-1">
                                    <span class="small text-muted"><i class="fas fa-user me-1"></i> ${item.name}</span>
                                    <span class="badge ${item.level === 'National' ? 'bg-info' : 'bg-light text-dark'} border" style="font-size: 9px;">${item.level}</span>
                                </div>
                            </div>
                            <div class="text-end border-start ps-4">
                                <div class="fw-bold text-dark small">${item.date}</div>
                                <div class="extra-small text-muted">${item.id}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.recordNewAward = function() {
        const modalEl = document.getElementById('awardsCommendationModal');
        const titleEl = document.getElementById('awardsCommendationModalTitle');
        const bodyEl = document.getElementById('awardsCommendationModalBody');
        const footerEl = document.getElementById('awardsCommendationModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Record Commendation';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Official Award Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="commendationTitleInput" placeholder="e.g. DOH Excellence in Service">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Recipient Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="commendationNameInput" placeholder="e.g. Dr. Aris Thorne">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Award Level</label>',
            '  <select class="form-select form-select-sm" id="commendationLevelInput">',
            '    <option>Institutional</option>',
            '    <option>Regional</option>',
            '    <option>National</option>',
            '  </select>',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-dark" id="commendationSaveBtn">Record</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('commendationSaveBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const title = (document.getElementById('commendationTitleInput').value || '').trim();
                const name = (document.getElementById('commendationNameInput').value || '').trim();
                const level = (document.getElementById('commendationLevelInput').value || 'Institutional').trim();
                if (!title || !name) {
                    return;
                }

                let data = getCommendations();
                data.unshift({
                    id: 'CERT-2026-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    title: title,
                    level: level,
                    date: new Date().toISOString().split('T')[0]
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderAwardsCommendations(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showCommendationInfo('Commendation Recorded', title + ' has been added for ' + name + '.');
            });
        }

        modal.show();
    };

})();