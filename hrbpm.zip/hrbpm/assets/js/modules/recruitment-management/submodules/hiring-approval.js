/**
 * Hiring Approval Submodule with Audit History & Applicant Integration
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const QUEUE_KEY = 'hospitalHrHiringApprovals';
    const HISTORY_KEY = 'hospitalHrApprovalHistory';
    const CANDIDATES_KEY = 'hrCandidates'; // Link to your applicant list

    const getStorageData = (key, defaults) => {
        const stored = localStorage.getItem(key);
        return stored ? JSON.parse(stored) : defaults;
    };

    function ensureHiringDecisionModal() {
        if (document.getElementById('hiringDecisionModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="hiringDecisionModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="hiringDecisionModalTitle">Confirm Decision</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="hiringDecisionModalBody"></div>',
            '      <div class="modal-footer" id="hiringDecisionModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function openHiringDecisionModal(target, outcome, onConfirm) {
        const modalEl = document.getElementById('hiringDecisionModal');
        const titleEl = document.getElementById('hiringDecisionModalTitle');
        const bodyEl = document.getElementById('hiringDecisionModalBody');
        const footerEl = document.getElementById('hiringDecisionModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        const approving = outcome === 'Approved';
        titleEl.textContent = approving ? 'Approve Candidate' : 'Reject Candidate';
        bodyEl.innerHTML = '<p class="mb-0">' +
            (approving
                ? 'Approve <strong>' + target.name + '</strong> for final hiring?'
                : 'Reject <strong>' + target.name + '</strong> at final approval stage?') +
            '</p>';
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn ' + (approving ? 'btn-success' : 'btn-danger') + '" id="hiringDecisionConfirmBtn">Confirm</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const confirmBtn = document.getElementById('hiringDecisionConfirmBtn');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function () {
                onConfirm();
                modal.hide();
            });
        }

        modal.show();
    }

    window.HRSubmodules.renderHiringApproval = function (container) {
        ensureHiringDecisionModal();

        // Fetch candidates from the main applicant list who are ready for final sign-off
        const allCandidates = getStorageData(CANDIDATES_KEY, []);
        
        // Filter for candidates who are in 'Shortlisted' stage (Awaiting final approval)
        const applicantQueue = allCandidates.filter(c => c.stage === 'Shortlisted');
        
        // Combine with any manual approvals in the local queue
        const manualQueue = getStorageData(QUEUE_KEY, [
            { id: "APP-501", name: "Dr. Aris Thorne", role: "Chief Resident", dept: "Emergency" }
        ]);
        
        const combinedQueue = [...applicantQueue, ...manualQueue];
        const history = getStorageData(HISTORY_KEY, []);

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark">Hiring Decision Center</h6>
                        <small class="text-muted">Final authorization for applicants and requisitions</small>
                    </div>
                    <span class="badge bg-primary px-3">${combinedQueue.length} Ready for Review</span>
                </div>

                <div class="row g-3 mb-5">
                    ${combinedQueue.length > 0 ? combinedQueue.map(app => `
                        <div class="col-md-6">
                            <div class="approval-card p-3 border rounded-3 bg-white shadow-sm d-flex justify-content-between align-items-center">
                                <div class="text-truncate me-3">
                                    <div class="fw-bold text-dark text-truncate">${app.name}</div>
                                    <div class="text-primary extra-small">${app.role || app.position || 'Staff Position'}</div>
                                    <span class="badge bg-info-subtle text-info extra-small" style="font-size: 9px">Candidate Pool</span>
                                </div>
                                <div class="d-flex gap-2 shrink-0">
                                    <button class="btn btn-sm btn-success px-3" onclick="window.HRSubmodules.confirmApprovalDecision('${app.id}', 'Approved')">Approve</button>
                                    <button class="btn btn-sm btn-outline-danger" onclick="window.HRSubmodules.confirmApprovalDecision('${app.id}', 'Rejected')">Deny</button>
                                </div>
                            </div>
                        </div>
                    `).join('') : '<div class="col-12 text-center text-muted p-4 border rounded-3 border-dashed">No applicants currently awaiting final approval.</div>'}
                </div>

                <hr class="my-4 opacity-25">

                <div class="history-section">
                    <h6 class="fw-bold mb-3"><i class="fas fa-history me-2 text-muted"></i>Decision History Log</h6>
                    <div class="table-responsive border rounded-3 bg-white shadow-sm">
                        <table class="table table-hover align-middle mb-0 history-table">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-3" style="width: 40%">Candidate</th>
                                    <th style="width: 30%">Decision</th>
                                    <th class="text-end pe-3" style="width: 30%">Timestamp</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${history.length > 0 ? history.map(item => `
                                    <tr>
                                        <td class="ps-3">
                                            <div class="fw-bold small text-dark">${item.name}</div>
                                            <div class="text-muted" style="font-size: 10px;">${item.role || item.position}</div>
                                        </td>
                                        <td>
                                            <span class="badge ${item.outcome === 'Approved' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'} border">
                                                ${item.outcome}
                                            </span>
                                        </td>
                                        <td class="text-end pe-3 text-muted small">${item.timestamp}</td>
                                    </tr>
                                `).join('') : '<tr><td colspan="3" class="text-center p-4 text-muted">No decisions logged yet.</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.confirmApprovalDecision = function(id, outcome) {
        const queue = getStorageData(QUEUE_KEY, []);
        const applicants = getStorageData(CANDIDATES_KEY, []);
        const target = queue.find(function (item) { return item.id === id; }) || applicants.find(function (item) { return item.id === id; });

        if (!target) {
            return;
        }

        openHiringDecisionModal(target, outcome, function () {
            window.HRSubmodules.processApproval(id, outcome);
        });
    };

    window.HRSubmodules.processApproval = function(id, outcome) {
        let queue = getStorageData(QUEUE_KEY, []);
        let applicants = getStorageData(CANDIDATES_KEY, []);
        let history = getStorageData(HISTORY_KEY, []);
        
        // Find if the target is in the manual queue OR the applicant list
        let target = queue.find(a => a.id === id) || applicants.find(a => a.id === id);
        
        if (target) {
            const decision = {
                id: target.id,
                name: target.name,
                role: target.role || target.position,
                outcome: outcome,
                timestamp: new Date().toLocaleString([], { hour: '2-digit', minute: '2-digit', month: 'short', day: 'numeric' })
            };

            // 1. Add to history
            history.unshift(decision);

            // 2. Clean up manual queue
            queue = queue.filter(a => a.id !== id);

            // 3. Update Applicant List Status
            const appIdx = applicants.findIndex(a => a.id === id);
            if (appIdx !== -1) {
                applicants[appIdx].stage = (outcome === 'Approved') ? 'Hired' : 'Rejected';
            }

            // Save all updates
            localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
            localStorage.setItem(CANDIDATES_KEY, JSON.stringify(applicants));
            localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 10)));

            // 4. Global Stats Update (Dashboard Sync)
            if (outcome === 'Approved') {
                const count = parseInt(localStorage.getItem('hospitalHrHiredCount') || 0);
                localStorage.setItem('hospitalHrHiredCount', count + 1);
            }

            window.dispatchEvent(new Event('storage'));
            this.renderHiringApproval(document.getElementById('roleModuleOverviewBody'));
        }
    };

})();