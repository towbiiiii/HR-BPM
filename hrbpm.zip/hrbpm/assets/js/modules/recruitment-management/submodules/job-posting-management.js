/**
 * Job Posting Management Submodule
 * Professional Vacancy Lifecycle Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};

    // Initial Data State - Mocking a Hospital Vacancy List
    let jobPostings = JSON.parse(localStorage.getItem('hospitalHrJobPostings')) || [
        { id: "JOB-2026-001", title: "Registered Nurse (ICU)", dept: "Nursing", type: "Full-time", apps: 12, status: "Active" },
        { id: "JOB-2026-002", title: "Medical Technologist", dept: "Laboratory", type: "Full-time", apps: 8, status: "Active" },
        { id: "JOB-2026-003", title: "HR Generalist", dept: "Human Resources", type: "Contract", apps: 25, status: "Closed" }
    ];

    function ensureJobModalHost() {
        if (document.getElementById('jobPostingModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="jobPostingModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="jobPostingModalTitle">Job Posting Action</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="jobPostingModalBody"></div>',
            '      <div class="modal-footer" id="jobPostingModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function openJobInfoModal(title, message) {
        const modalEl = document.getElementById('jobPostingModal');
        const titleEl = document.getElementById('jobPostingModalTitle');
        const bodyEl = document.getElementById('jobPostingModalBody');
        const footerEl = document.getElementById('jobPostingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderJobPostingManagement = function (container) {
        ensureJobModalHost();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-actionbar d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="mb-0 fw-bold"><i class="fas fa-briefcase text-primary me-2"></i>Job Vacancy Manager</h6>
                        <small class="text-muted">Currently managing ${jobPostings.filter(j => j.status === 'Active').length} active listings</small>
                    </div>
                    <button class="btn btn-primary btn-sm shadow-sm px-3" onclick="window.HRSubmodules.openNewJobModal()">
                        <i class="fas fa-plus-circle me-2"></i>Post New Opening
                    </button>
                </div>

                <div class="row g-3" id="jobGridContainer">
                    ${jobPostings.map(job => `
                        <div class="col-md-6 col-lg-4">
                            <div class="job-card p-3 border rounded-3 bg-white shadow-sm position-relative ${job.status === 'Closed' ? 'opacity-75' : ''}">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="badge ${job.status === 'Active' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary'}">
                                        ${job.status}
                                    </span>
                                    <div class="dropdown">
                                        <button class="btn btn-link btn-sm text-muted p-0" data-bs-toggle="dropdown"><i class="fas fa-ellipsis-v"></i></button>
                                        <ul class="dropdown-menu shadow-sm border-0">
                                            <li><a class="dropdown-item small" href="#" onclick="window.HRSubmodules.toggleJobStatus('${job.id}')">Toggle Status</a></li>
                                            <li><a class="dropdown-item small text-danger" href="#" onclick="window.HRSubmodules.confirmDeleteJob('${job.id}')">Delete Post</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">${job.title}</h6>
                                <p class="text-muted extra-small mb-3"><i class="fas fa-hospital-alt me-1"></i>${job.dept} &bull; ${job.type}</p>
                                
                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <div class="text-center">
                                        <div class="fw-bold text-primary mb-0">${job.apps}</div>
                                        <div class="extra-small text-muted">Applicants</div>
                                    </div>
                                    <button class="btn btn-sm btn-light border px-3" style="font-size: 11px;" onclick="window.HRSubmodules.viewJobCandidates('${job.id}')">View Candidates</button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.toggleJobStatus = function(id) {
        const job = jobPostings.find(j => j.id === id);
        if (job) {
            job.status = job.status === 'Active' ? 'Closed' : 'Active';
            this.syncJobData();
            this.renderJobPostingManagement(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.syncJobData = function() {
        localStorage.setItem('hospitalHrJobPostings', JSON.stringify(jobPostings));
        // Update Dashboard Specific Key
        localStorage.setItem('hospitalHrActiveJobs', jobPostings.filter(j => j.status === 'Active').length);
        window.dispatchEvent(new Event('storage'));
    };

    window.HRSubmodules.openNewJobModal = function() {
        const modalEl = document.getElementById('jobPostingModal');
        const titleEl = document.getElementById('jobPostingModalTitle');
        const bodyEl = document.getElementById('jobPostingModalBody');
        const footerEl = document.getElementById('jobPostingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Post New Opening';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Job Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="jobNewTitle" placeholder="e.g. Nurse Supervisor">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Department</label>',
            '  <input type="text" class="form-control form-control-sm" id="jobNewDept" placeholder="e.g. Nursing">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Employment Type</label>',
            '  <select class="form-select form-select-sm" id="jobNewType">',
            '    <option>Full-time</option>',
            '    <option>Part-time</option>',
            '    <option>Contract</option>',
            '  </select>',
            '</div>'
        ].join('');

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="jobCreateConfirm">Create Posting</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('jobCreateConfirm');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const jobTitle = (document.getElementById('jobNewTitle').value || '').trim();
                const jobDept = (document.getElementById('jobNewDept').value || '').trim() || 'General Medicine';
                const jobType = (document.getElementById('jobNewType').value || 'Full-time').trim();

                if (!jobTitle) {
                    return;
                }

                jobPostings.unshift({
                    id: 'JOB-' + Date.now().toString().slice(-6),
                    title: jobTitle,
                    dept: jobDept,
                    type: jobType,
                    apps: 0,
                    status: 'Active'
                });

                window.HRSubmodules.syncJobData();
                window.HRSubmodules.renderJobPostingManagement(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.confirmDeleteJob = function (id) {
        const target = jobPostings.find(function (item) {
            return item.id === id;
        });
        if (!target) {
            return;
        }

        const modalEl = document.getElementById('jobPostingModal');
        const titleEl = document.getElementById('jobPostingModalTitle');
        const bodyEl = document.getElementById('jobPostingModalBody');
        const footerEl = document.getElementById('jobPostingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Delete Job Posting';
        bodyEl.innerHTML = '<p class="mb-0">Delete <strong>' + target.title + '</strong> (' + target.id + ')? This action cannot be undone.</p>';
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-danger" id="jobDeleteConfirm">Delete</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const deleteBtn = document.getElementById('jobDeleteConfirm');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                jobPostings = jobPostings.filter(function (item) {
                    return item.id !== id;
                });
                window.HRSubmodules.syncJobData();
                window.HRSubmodules.renderJobPostingManagement(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.viewJobCandidates = function (id) {
        const target = jobPostings.find(function (item) {
            return item.id === id;
        });
        if (!target) {
            return;
        }

        openJobInfoModal('Candidate Snapshot', target.title + ' currently has ' + target.apps + ' applicants in the pipeline.');
    };

})();