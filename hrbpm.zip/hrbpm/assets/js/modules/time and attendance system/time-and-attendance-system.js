window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    // Use data from PHP if available, otherwise fallback to localStorage
    function getAttendanceRecords() {
        if (window.hrAttendanceData && window.hrAttendanceData.records && window.hrAttendanceData.records.length > 0) {
            return window.hrAttendanceData.records.map(record => ({
                employee: record.employee_name || record.employee,
                department: record.department_name || record.department,
                timeIn: record.time_in || record.timeIn || '-',
                status: record.status || 'No Log-in'
            }));
        }
        
        // Fallback to localStorage if no PHP data
        const stored = localStorage.getItem('hospitalHrAttendanceRecords');
        if (stored) {
            try {
                return JSON.parse(stored);
            } catch (e) {
                return getAttendanceSeedData();
            }
        }
        return getAttendanceSeedData();
    }

    function getAttendanceSeedData() {
        return [
            { employee: 'Anna Santos', department: 'HR Operations', timeIn: '08:02 AM', status: 'Present' },
            { employee: 'Mark Rivera', department: 'Finance', timeIn: '08:21 AM', status: 'Late' },
            { employee: 'Liza De Leon', department: 'Nursing', timeIn: '-', status: 'No Log-in' },
            { employee: 'Paolo Cruz', department: 'HR Operations', timeIn: '-', status: 'On Leave' },
            { employee: 'Jude Molina', department: 'Operations', timeIn: '07:58 AM', status: 'Present' },
            { employee: 'Mara Lopez', department: 'Nursing', timeIn: '08:17 AM', status: 'Late' }
        ];
    }

    function getStorageList(key, fallback) {
        // For validation queue and correction requests, try PHP data first
        if (key === 'hospitalHrAttendanceValidationQueue' && window.hrAttendanceData && window.hrAttendanceData.validationQueue) {
            return window.hrAttendanceData.validationQueue.map(item => ({
                id: item.request_id || item.id,
                employee: item.employee_name || item.employee,
                issue: item.issue,
                status: item.status
            }));
        }
        
        if (key === 'hospitalHrCorrectionRequests' && window.hrAttendanceData && window.hrAttendanceData.correctionRequests) {
            return window.hrAttendanceData.correctionRequests;
        }

        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {}

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    // Attendance Monitoring
    registry.renderAttendanceMonitoring = function (container) {
        const records = getAttendanceRecords();
        
        container.innerHTML = [
            '<div class="card border-0 shadow-sm att-mon-submodule">',
            '  <div class="card-body">',
            '    <div class="d-flex align-items-center gap-2 mb-3">',
            '      <i class="fas fa-user-check text-primary"></i>',
            '      <h6 class="mb-0">Attendance Monitoring</h6>',
            '    </div>',
            '    <div class="row g-3 mb-3">',
            '      <div class="col-md-4">',
            '        <input id="attMonSearch" class="form-control" placeholder="Search employee">',
            '      </div>',
            '      <div class="col-md-3">',
            '        <select id="attMonStatus" class="form-select">',
            '          <option value="All">All Status</option>',
            '          <option value="Present">Present</option>',
            '          <option value="Late">Late</option>',
            '          <option value="On Leave">On Leave</option>',
            '          <option value="No Log-in">No Log-in</option>',
            '          <option value="Absent">Absent</option>',
            '        </select>',
            '      </div>',
            '    </div>',
            '    <div id="attMonKpis" class="row g-3 mb-3"></div>',
            '    <div class="table-responsive">',
            '      <table class="table table-sm align-middle mb-0">',
            '        <thead>',
            '          <tr>',
            '            <th>Employee</th>',
            '            <th>Department</th>',
            '            <th>Time In</th>',
            '            <th>Status</th>',
            '          </tr>',
            '        </thead>',
            '        <tbody id="attMonRows"></tbody>',
            '      </table>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        const searchInput = document.getElementById('attMonSearch');
        const statusSelect = document.getElementById('attMonStatus');
        const rowsEl = document.getElementById('attMonRows');
        const kpisEl = document.getElementById('attMonKpis');

        function render() {
            const query = (searchInput.value || '').toLowerCase().trim();
            const status = statusSelect.value;
            
            const filtered = records.filter(function (row) {
                const matchesStatus = status === 'All' || row.status === status;
                const matchesQuery = !query || 
                    (row.employee && row.employee.toLowerCase().indexOf(query) !== -1) || 
                    (row.department && row.department.toLowerCase().indexOf(query) !== -1);
                return matchesStatus && matchesQuery;
            });

            // Calculate KPIs
            const present = filtered.filter(r => r.status === 'Present').length;
            const late = filtered.filter(r => r.status === 'Late').length;
            const onLeave = filtered.filter(r => r.status === 'On Leave').length;
            const noLogin = filtered.filter(r => r.status === 'No Log-in' || r.status === 'Absent').length;

            kpisEl.innerHTML = [
                '<div class="col-md-3">',
                '  <div class="border rounded-3 p-3">',
                '    <p class="text-muted mb-1">Present</p>',
                '    <h5 class="mb-0">' + present + '</h5>',
                '  </div>',
                '</div>',
                '<div class="col-md-3">',
                '  <div class="border rounded-3 p-3">',
                '    <p class="text-muted mb-1">Late</p>',
                '    <h5 class="mb-0">' + late + '</h5>',
                '  </div>',
                '</div>',
                '<div class="col-md-3">',
                '  <div class="border rounded-3 p-3">',
                '    <p class="text-muted mb-1">On Leave</p>',
                '    <h5 class="mb-0">' + onLeave + '</h5>',
                '  </div>',
                '</div>',
                '<div class="col-md-3">',
                '  <div class="border rounded-3 p-3">',
                '    <p class="text-muted mb-1">No Log-in</p>',
                '    <h5 class="mb-0">' + noLogin + '</h5>',
                '  </div>',
                '</div>'
            ].join('');

            rowsEl.innerHTML = filtered.map(function (row) {
                const badgeClass = row.status === 'Present'
                    ? 'bg-success-subtle text-success'
                    : row.status === 'Late'
                        ? 'bg-warning-subtle text-warning'
                        : row.status === 'On Leave'
                            ? 'bg-info-subtle text-info'
                            : 'bg-danger-subtle text-danger';
                
                return '<tr>' +
                    '<td>' + (row.employee || 'N/A') + '</td>' +
                    '<td>' + (row.department || 'N/A') + '</td>' +
                    '<td>' + (row.timeIn || '-') + '</td>' +
                    '<td><span class="badge ' + badgeClass + '">' + (row.status || 'Unknown') + '</span></td>' +
                    '</tr>';
            }).join('');
        }

        if (searchInput) searchInput.addEventListener('input', render);
        if (statusSelect) statusSelect.addEventListener('change', render);
        render();
    };

    // Attendance Validation
    registry.renderAttendanceValidation = function (container) {
        ensureModalHost('attendanceValidationModal');
        
        const fallback = [
            { id: 'VAL-1001', employee: 'Paolo Cruz', issue: 'Missing Time In', status: 'Pending' },
            { id: 'VAL-1002', employee: 'Rina Torres', issue: 'Late Log Entry', status: 'Pending' },
            { id: 'VAL-1003', employee: 'John Lim', issue: 'Early Out Dispute', status: 'For Review' }
        ];
        
        let queue = getStorageList('hospitalHrAttendanceValidationQueue', fallback);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm att-val-submodule">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0">',
                '      <i class="fas fa-clipboard-check text-primary me-2"></i>',
                '      Pending Validation Queue',
                '    </h5>',
                '    <span class="badge bg-warning-subtle text-warning">',
                queue.filter(i => i.status === 'Pending' || i.status === 'For Review').length + ' Open',
                '    </span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead>',
                '        <tr><th>ID</th><th>Employee</th><th>Issue</th><th>Status</th><th>Action</th></tr>',
                '      </thead>',
                '      <tbody>',
                queue.map(item => {
                    const statusClass = item.status === 'Approved' 
                        ? 'bg-success-subtle text-success' 
                        : item.status === 'Rejected' 
                            ? 'bg-danger-subtle text-danger' 
                            : 'bg-warning-subtle text-warning';
                    
                    return '<tr>' +
                        '<td>' + item.id + '</td>' +
                        '<td>' + item.employee + '</td>' +
                        '<td>' + item.issue + '</td>' +
                        '<td><span class="badge ' + statusClass + '">' + item.status + '</span></td>' +
                        '<td>' +
                        '<button class="btn btn-sm btn-outline-success me-1" data-action="approve" data-id="' + item.id + '">Approve</button>' +
                        '<button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.id + '">Reject</button>' +
                        '</td>' +
                        '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action]').forEach(button => {
                button.addEventListener('click', function () {
                    const action = this.getAttribute('data-action');
                    const id = this.getAttribute('data-id');
                    const target = queue.find(item => item.id === id);
                    
                    if (!target) return;

                    const nextStatus = action === 'approve' ? 'Approved' : 'Rejected';
                    
                    showModal({
                        modalId: 'attendanceValidationModal',
                        title: nextStatus === 'Approved' ? 'Approve Validation' : 'Reject Validation',
                        message: `Set request ${target.id} for ${target.employee} to ${nextStatus}?`,
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn ' + (nextStatus === 'Approved' ? 'btn-success' : 'btn-danger') + '" id="confirmAction">Confirm</button>'
                        ].join(''),
                        onConfirm: function(modal) {
                            queue = queue.map(item => {
                                if (item.id === id) {
                                    return { ...item, status: nextStatus };
                                }
                                return item;
                            });
                            setStorageList('hospitalHrAttendanceValidationQueue', queue);
                            modal.hide();
                            render();
                            
                            showModal({
                                modalId: 'attendanceValidationModal',
                                title: 'Validation Updated',
                                message: `Request ${target.id} is now marked as ${nextStatus}.`
                            });
                        }
                    });
                });
            });
        }

        render();
    };

    // Attendance Reports
    registry.renderAttendanceReports = function (container) {
        ensureModalHost('attendanceReportsModal');
        
        const records = getAttendanceRecords();
        
        // Calculate department statistics
        const departments = {};
        records.forEach(row => {
            const dept = row.department || 'Unknown';
            if (!departments[dept]) {
                departments[dept] = { total: 0, late: 0, absences: 0 };
            }
            departments[dept].total += 1;
            if (row.status === 'Late') departments[dept].late += 1;
            if (row.status === 'No Log-in' || row.status === 'Absent') departments[dept].absences += 1;
        });

        // Calculate overall statistics
        const totalEmployees = records.length;
        const totalAbsences = records.filter(r => r.status === 'No Log-in' || r.status === 'Absent').length;
        const totalLate = records.filter(r => r.status === 'Late').length;
        const attendanceRate = totalEmployees > 0 ? Math.round(((totalEmployees - totalAbsences) / totalEmployees) * 100) : 0;

        const rows = Object.keys(departments).map(dept => {
            const info = departments[dept];
            const rate = Math.round(((info.total - info.absences) / info.total) * 100);
            return '<tr><td>' + dept + '</td><td>' + rate + '%</td><td>' + info.late + '</td><td>' + info.absences + '</td></tr>';
        }).join('');

        container.innerHTML = [
            '<div class="d-flex justify-content-between align-items-center mb-3 att-reports-submodule">',
            '  <h6 class="mb-0"><i class="fas fa-chart-column text-primary me-2"></i>Attendance Reports</h6>',
            '  <button id="attExportCsv" class="btn btn-outline-secondary btn-sm">Export CSV</button>',
            '</div>',
            '<div class="row g-3 mb-3">',
            '  <div class="col-md-4">',
            '    <div class="border rounded-3 p-3">',
            '      <p class="text-muted mb-1">Attendance Rate</p>',
            '      <h5 class="mb-0">' + attendanceRate + '%</h5>',
            '    </div>',
            '  </div>',
            '  <div class="col-md-4">',
            '    <div class="border rounded-3 p-3">',
            '      <p class="text-muted mb-1">Late Incidents</p>',
            '      <h5 class="mb-0">' + totalLate + '</h5>',
            '    </div>',
            '  </div>',
            '  <div class="col-md-4">',
            '    <div class="border rounded-3 p-3">',
            '      <p class="text-muted mb-1">Absences</p>',
            '      <h5 class="mb-0">' + totalAbsences + '</h5>',
            '    </div>',
            '  </div>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white">',
            '    <h5 class="mb-0">Department Attendance Summary</h5>',
            '  </div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead>',
            '        <tr><th>Department</th><th>Attendance Rate</th><th>Late Cases</th><th>Absences</th></tr>',
            '      </thead>',
            '      <tbody>' + rows + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');

        const exportButton = document.getElementById('attExportCsv');
        if (exportButton) {
            exportButton.addEventListener('click', function () {
                showModal({
                    modalId: 'attendanceReportsModal',
                    title: 'Export Attendance CSV',
                    message: 'Generate and download the attendance summary CSV now?',
                    footerHtml: [
                        '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                        '<button type="button" class="btn btn-primary" id="confirmExport">Export</button>'
                    ].join(''),
                    onConfirm: function(modal) {
                        // Generate CSV
                        const csvLines = ['Department,Attendance Rate,Late Cases,Absences'];
                        Object.keys(departments).forEach(dept => {
                            const info = departments[dept];
                            const rate = Math.round(((info.total - info.absences) / info.total) * 100);
                            csvLines.push([dept, rate + '%', info.late, info.absences].join(','));
                        });

                        const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
                        const link = document.createElement('a');
                        link.href = URL.createObjectURL(blob);
                        link.download = 'attendance-report-' + new Date().toISOString().split('T')[0] + '.csv';
                        link.click();
                        URL.revokeObjectURL(link.href);
                        modal.hide();
                        
                        showModal({
                            modalId: 'attendanceReportsModal',
                            title: 'Export Complete',
                            message: 'Attendance report CSV has been downloaded.'
                        });
                    }
                });
            });
        }
    };

    // Correction Requests
    registry.renderCorrectionRequests = function (container) {
        ensureModalHost('correctionRequestsModal');
        
        const fallback = [
            { id: 'CR-1042', employee: 'Anna Santos', issue: 'Missing Time Out', status: 'Pending' },
            { id: 'CR-1041', employee: 'Miguel Reyes', issue: 'Wrong Shift Tag', status: 'Approved' },
            { id: 'CR-1038', employee: 'Leah Gomez', issue: 'Late Log Adjustment', status: 'Rejected' }
        ];
        
        let requests = getStorageList('hospitalHrCorrectionRequests', fallback);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 corr-req-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-pen-to-square text-primary me-2"></i>Submit New Correction Request</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-4">',
                '        <input id="corrEmployee" class="form-control" placeholder="Employee name">',
                '      </div>',
                '      <div class="col-md-5">',
                '        <input id="corrIssue" class="form-control" placeholder="Issue description">',
                '      </div>',
                '      <div class="col-md-3">',
                '        <button id="corrAddBtn" class="btn btn-primary w-100">Add Request</button>',
                '      </div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white">',
                '    <h5 class="mb-0"><i class="fas fa-list-check text-primary me-2"></i>Correction Request Tracker</h5>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead>',
                '        <tr><th>Request ID</th><th>Employee</th><th>Issue</th><th>Status</th></tr>',
                '      </thead>',
                '      <tbody>',
                requests.map(item => {
                    const badge = item.status === 'Approved'
                        ? 'bg-success-subtle text-success'
                        : item.status === 'Rejected'
                            ? 'bg-danger-subtle text-danger'
                            : 'bg-warning-subtle text-warning';
                    
                    return '<tr>' +
                        '<td>' + item.id + '</td>' +
                        '<td>' + item.employee + '</td>' +
                        '<td>' + item.issue + '</td>' +
                        '<td><span class="badge ' + badge + '">' + item.status + '</span></td>' +
                        '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('corrAddBtn');
            if (addButton) {
                addButton.addEventListener('click', function () {
                    const employee = (document.getElementById('corrEmployee').value || '').trim();
                    const issue = (document.getElementById('corrIssue').value || '').trim();
                    
                    if (!employee || !issue) {
                        showModal({
                            modalId: 'correctionRequestsModal',
                            title: 'Incomplete Request',
                            message: 'Enter both employee name and issue description before adding a request.'
                        });
                        return;
                    }

                    const nextNumber = 1000 + requests.length + 1;
                    requests.unshift({
                        id: 'CR-' + nextNumber,
                        employee: employee,
                        issue: issue,
                        status: 'Pending'
                    });
                    
                    setStorageList('hospitalHrCorrectionRequests', requests);
                    render();
                    
                    // Clear inputs
                    document.getElementById('corrEmployee').value = '';
                    document.getElementById('corrIssue').value = '';
                    
                    showModal({
                        modalId: 'correctionRequestsModal',
                        title: 'Request Added',
                        message: 'Correction request for ' + employee + ' has been filed.'
                    });
                });
            }
        }

        render();
    };

    // Helper Functions
    function ensureModalHost(modalId) {
        if (document.getElementById(modalId)) return;

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="' + modalId + '" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="' + modalId + 'Title"></h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="' + modalId + 'Body"></div>',
            '      <div class="modal-footer" id="' + modalId + 'Footer"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showModal(config) {
        const modalEl = document.getElementById(config.modalId);
        const titleEl = document.getElementById(config.modalId + 'Title');
        const bodyEl = document.getElementById(config.modalId + 'Body');
        const footerEl = document.getElementById(config.modalId + 'Footer');
        
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !window.bootstrap) return;

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (config.onConfirm) {
            const confirmBtn = document.getElementById('confirmAction') || document.getElementById('confirmExport');
            if (confirmBtn) {
                confirmBtn.addEventListener('click', function () {
                    config.onConfirm(modal);
                }, { once: true });
            }
        }
    }

})(window.HRSubmodules);

// Initialize submodule switching
(function () {
    const container = document.getElementById('tasSubmoduleContainer');
    const buttons = document.querySelectorAll('button[data-submodule]');
    
    const rendererMap = {
        'Attendance Monitoring': 'renderAttendanceMonitoring',
        'Attendance Validation': 'renderAttendanceValidation',
        'Attendance Reports': 'renderAttendanceReports',
        'Correction Requests': 'renderCorrectionRequests'
    };

    function setActiveButton(activeName) {
        buttons.forEach(button => {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(submoduleName) {
        if (!container) return;

        const rendererName = rendererMap[submoduleName];
        const renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            renderer(container);
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer is not available.</div>';
        }

        setActiveButton(submoduleName);
    }

    buttons.forEach(button => {
        button.addEventListener('click', function () {
            renderSubmodule(this.getAttribute('data-submodule'));
        });
    });

    // Start with Attendance Monitoring
    renderSubmodule('Attendance Monitoring');
})();