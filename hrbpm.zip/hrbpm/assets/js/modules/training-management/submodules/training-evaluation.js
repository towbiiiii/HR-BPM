/**
 * Training Evaluation Submodule
 * Professional Feedback & Quality Metrics
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrEvaluations';

    const getEvaluations = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Initial Professional Feedback Data
        return [
            { id: "EVL-501", course: "Advanced Life Support", staff: "Dr. Aris Thorne", rating: 5, comment: "Excellent hands-on simulation.", date: "2024-06-16" },
            { id: "EVL-502", course: "HIPAA Compliance", staff: "Sarah Jenkins", rating: 3, comment: "A bit long, but informative.", date: "2024-06-15" },
            { id: "EVL-503", course: "Emergency Response", staff: "James Miller", rating: 4, comment: "Very practical for night shifts.", date: "2024-06-14" }
        ];
    };

    function ensureTrainingEvaluationModalHost() {
        if (document.getElementById('trainingEvaluationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="trainingEvaluationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="trainingEvaluationModalTitle">Training Evaluation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="trainingEvaluationModalBody"></div>',
            '      <div class="modal-footer" id="trainingEvaluationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showTrainingEvaluationInfo(title, message) {
        const modalEl = document.getElementById('trainingEvaluationModal');
        const titleEl = document.getElementById('trainingEvaluationModalTitle');
        const bodyEl = document.getElementById('trainingEvaluationModalBody');
        const footerEl = document.getElementById('trainingEvaluationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderTrainingEvaluation = function (container) {
        ensureTrainingEvaluationModalHost();

        const evals = getEvaluations();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-star-half-stroke text-warning me-2"></i>Training Quality Feedback</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Post-session Staff Evaluations</small>
                    </div>
                    <button class="btn btn-warning btn-sm text-white rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.submitNewEvaluation()">
                        <i class="fas fa-pen-nib me-1"></i> New Evaluation
                    </button>
                </div>

                <div class="row g-3">
                    ${evals.map(evalItem => `
                        <div class="col-xl-6 col-md-12">
                            <div class="eval-card bg-white border rounded-4 p-3 shadow-sm h-100">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <div class="fw-bold text-dark small">${evalItem.course}</div>
                                        <div class="extra-small text-muted">${evalItem.staff} • ${evalItem.date}</div>
                                    </div>
                                    <div class="rating-stars text-warning small">
                                        ${Array(5).fill(0).map((_, i) => `<i class="${i < evalItem.rating ? 'fas' : 'far'} fa-star"></i>`).join('')}
                                    </div>
                                </div>
                                <div class="eval-comment bg-light p-2 rounded-3 mt-2">
                                    <p class="mb-0 text-muted italic small font-serif">"${evalItem.comment}"</p>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.submitNewEvaluation = function() {
        const modalEl = document.getElementById('trainingEvaluationModal');
        const titleEl = document.getElementById('trainingEvaluationModalTitle');
        const bodyEl = document.getElementById('trainingEvaluationModalBody');
        const footerEl = document.getElementById('trainingEvaluationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Submit Evaluation';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Course Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingEvalCourse" placeholder="e.g. Emergency Response">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Rating (1-5)</label>',
            '  <input type="number" class="form-control form-control-sm" id="trainingEvalRating" min="1" max="5" step="1" value="5">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Feedback Comment</label>',
            '  <textarea class="form-control form-control-sm" id="trainingEvalComment" rows="3" placeholder="Share your feedback"></textarea>',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-warning text-white" id="trainingEvalSubmitBtn">Submit</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const submitBtn = document.getElementById('trainingEvalSubmitBtn');
        if (submitBtn) {
            submitBtn.addEventListener('click', function () {
                const course = (document.getElementById('trainingEvalCourse').value || '').trim();
                const ratingValue = parseInt((document.getElementById('trainingEvalRating').value || '').trim(), 10);
                const comment = (document.getElementById('trainingEvalComment').value || '').trim() || 'No comments provided.';
                if (!course || Number.isNaN(ratingValue)) {
                    return;
                }

                let evals = getEvaluations();
                evals.unshift({
                    id: 'EVL-' + Math.floor(500 + Math.random() * 499),
                    course: course,
                    staff: 'Current User',
                    rating: ratingValue,
                    comment: comment,
                    date: new Date().toISOString().split('T')[0]
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(evals));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderTrainingEvaluation(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showTrainingEvaluationInfo('Evaluation Saved', 'Your feedback for ' + course + ' has been recorded.');
            });
        }

        modal.show();
    };
})();