/**
 * Skill Inventory Submodule
 * Professional Medical & Administrative Talent Database
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrSkillInventory';

    const getSkills = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        return [
            { id: "SKL-001", name: "Dr. Aris Thorne", category: "Clinical", skills: ["Surgery", "ER", "Trauma"], level: "Expert" },
            { id: "SKL-002", name: "Sarah Jenkins", category: "Leadership", skills: ["Team Mgmt", "Nursing Ops"], level: "Advanced" },
            { id: "SKL-003", name: "James Miller", category: "Technical", skills: ["Radiology", "MRI"], level: "Intermediate" }
        ];
    };

    function ensureSkillInventoryModalHost() {
        if (document.getElementById('skillInventoryModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="skillInventoryModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="skillInventoryModalTitle">Skill Inventory</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="skillInventoryModalBody"></div>',
            '      <div class="modal-footer" id="skillInventoryModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showSkillInventoryInfo(title, message) {
        const modalEl = document.getElementById('skillInventoryModal');
        const titleEl = document.getElementById('skillInventoryModalTitle');
        const bodyEl = document.getElementById('skillInventoryModalBody');
        const footerEl = document.getElementById('skillInventoryModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderSkillInventory = function (container) {
        ensureSkillInventoryModalHost();

        const inventory = getSkills();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-header-container d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div class="header-info">
                        <h6 class="fw-bold mb-0 text-dark">Talent Inventory</h6>
                        <small class="text-muted">Specialized medical and technical competencies</small>
                    </div>
                    <button class="btn btn-sm btn-primary px-3 shadow-sm" onclick="window.HRSubmodules.addNewSkillEntry()">
                        <i class="fas fa-plus me-2"></i>Add Talent
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-skill-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 30%">Staff Member</th>
                                <th style="width: 45%">Competencies</th>
                                <th class="text-end pe-4" style="width: 25%">Proficiency</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${inventory.map(item => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark text-truncate">${item.name}</div>
                                        <div class="text-muted extra-small">ID: ${item.id}</div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-wrap gap-1">
                                            ${item.skills.map(s => `<span class="skill-tag">${s}</span>`).join('')}
                                        </div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <span class="level-badge ${item.level.toLowerCase()}">${item.level}</span>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.addNewSkillEntry = function() {
        const modalEl = document.getElementById('skillInventoryModal');
        const titleEl = document.getElementById('skillInventoryModalTitle');
        const bodyEl = document.getElementById('skillInventoryModalBody');
        const footerEl = document.getElementById('skillInventoryModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Add Talent Entry';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="skillEntryName" placeholder="e.g. John Doe">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Category</label>',
            '  <input type="text" class="form-control form-control-sm" id="skillEntryCategory" value="General">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Skills (comma separated)</label>',
            '  <input type="text" class="form-control form-control-sm" id="skillEntrySkills" placeholder="e.g. Triage, ER, Documentation">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="skillEntrySaveBtn">Save</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('skillEntrySaveBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const name = (document.getElementById('skillEntryName').value || '').trim();
                const category = (document.getElementById('skillEntryCategory').value || '').trim() || 'General';
                const skillsRaw = (document.getElementById('skillEntrySkills').value || '').trim();
                if (!name || !skillsRaw) {
                    return;
                }

                const inventory = getSkills();
                inventory.unshift({
                    id: 'SKL-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    category: category,
                    skills: skillsRaw.split(',').map(function (s) { return s.trim(); }).filter(Boolean),
                    level: 'Intermediate'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(inventory));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderSkillInventory(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showSkillInventoryInfo('Talent Added', name + ' was added to the skill inventory.');
            });
        }

        modal.show();
    };
})();