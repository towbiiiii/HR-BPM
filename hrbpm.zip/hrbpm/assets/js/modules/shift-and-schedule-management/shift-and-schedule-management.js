window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const SHIFT_DEFINITIONS_KEY = 'hospitalHrShiftDefinitions';

    function ensureShiftCreationModalHost() {
        if (document.getElementById('shiftCreationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="shiftCreationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="shiftCreationModalTitle">Shift Creation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="shiftCreationModalBody"></div>',
            '      <div class="modal-footer" id="shiftCreationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showShiftCreationInfo(title, message) {
        const modalEl = document.getElementById('shiftCreationModal');
        const titleEl = document.getElementById('shiftCreationModalTitle');
        const bodyEl = document.getElementById('shiftCreationModalBody');
        const footerEl = document.getElementById('shiftCreationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderShiftCreation = function (container) {
        ensureShiftCreationModalHost();

        const fallback = [
            { code: 'AM-8', name: 'Morning Shift', start: '08:00', end: '17:00', type: 'Regular' },
            { code: 'PM-8', name: 'Evening Shift', start: '14:00', end: '23:00', type: 'Regular' },
            { code: 'NS-10', name: 'Night Shift', start: '21:00', end: '07:00', type: 'Critical' }
        ];

        let shifts = getStorageList(SHIFT_DEFINITIONS_KEY, fallback);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 shift-create-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-calendar-plus text-primary me-2"></i>Create Shift Template</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-2"><input id="shiftCode" class="form-control" placeholder="Code"></div>',
                '      <div class="col-md-3"><input id="shiftName" class="form-control" placeholder="Shift Name"></div>',
                '      <div class="col-md-2"><input id="shiftStart" type="time" class="form-control"></div>',
                '      <div class="col-md-2"><input id="shiftEnd" type="time" class="form-control"></div>',
                '      <div class="col-md-2">',
                '        <select id="shiftType" class="form-select">',
                '          <option>Regular</option>',
                '          <option>Critical</option>',
                '          <option>On-call</option>',
                '        </select>',
                '      </div>',
                '      <div class="col-md-1"><button id="addShiftBtn" class="btn btn-primary w-100">Add</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-layer-group text-primary me-2"></i>Shift Templates</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Code</th><th>Name</th><th>Start</th><th>End</th><th>Type</th></tr></thead>',
                '      <tbody>',
                shifts.map(function (item) {
                    const badge = item.type === 'Critical' ? 'bg-danger-subtle text-danger' : item.type === 'On-call' ? 'bg-info-subtle text-info' : 'bg-success-subtle text-success';
                    return '<tr><td>' + item.code + '</td><td>' + item.name + '</td><td>' + item.start + '</td><td>' + item.end + '</td><td><span class="badge ' + badge + '">' + item.type + '</span></td></tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('addShiftBtn');
            if (!addButton) {
                return;
            }

            addButton.addEventListener('click', function () {
                const code = (document.getElementById('shiftCode').value || '').trim().toUpperCase();
                const name = (document.getElementById('shiftName').value || '').trim();
                const start = (document.getElementById('shiftStart').value || '').trim();
                const end = (document.getElementById('shiftEnd').value || '').trim();
                const type = (document.getElementById('shiftType').value || 'Regular').trim();

                if (!code || !name || !start || !end) {
                    showShiftCreationInfo('Incomplete Template', 'Fill in code, name, start, and end time before adding a shift template.');
                    return;
                }

                shifts.unshift({ code: code, name: name, start: start, end: end, type: type });
                setStorageList(SHIFT_DEFINITIONS_KEY, shifts);
                render();
                showShiftCreationInfo('Template Added', 'Shift template ' + code + ' (' + name + ') has been created.');
            });
        }

        render();
    };
})(window.HRSubmodules);

(function (registry) {
    const STAFF_SCHEDULE_KEY = 'hospitalHrStaffSchedule';

    function ensureStaffSchedulingModalHost() {
        if (document.getElementById('staffSchedulingModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="staffSchedulingModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="staffSchedulingModalTitle">Staff Scheduling</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="staffSchedulingModalBody"></div>',
            '      <div class="modal-footer" id="staffSchedulingModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showStaffSchedulingInfo(title, message) {
        const modalEl = document.getElementById('staffSchedulingModal');
        const titleEl = document.getElementById('staffSchedulingModalTitle');
        const bodyEl = document.getElementById('staffSchedulingModalBody');
        const footerEl = document.getElementById('staffSchedulingModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderStaffScheduling = function (container) {
        ensureStaffSchedulingModalHost();

        const fallback = [
            { employee: 'Anna Santos', unit: 'HR Ops', day: 'Monday', shift: 'AM-8' },
            { employee: 'Jude Molina', unit: 'Operations', day: 'Monday', shift: 'PM-8' },
            { employee: 'Liza De Leon', unit: 'Nursing', day: 'Monday', shift: 'NS-10' }
        ];

        let schedules = getStorageList(STAFF_SCHEDULE_KEY, fallback);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 staff-sched-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-user-clock text-primary me-2"></i>Assign Staff Schedule</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-3"><input id="schedEmployee" class="form-control" placeholder="Employee"></div>',
                '      <div class="col-md-3"><input id="schedUnit" class="form-control" placeholder="Unit"></div>',
                '      <div class="col-md-2">',
                '        <select id="schedDay" class="form-select">',
                '          <option>Monday</option><option>Tuesday</option><option>Wednesday</option><option>Thursday</option><option>Friday</option><option>Saturday</option><option>Sunday</option>',
                '        </select>',
                '      </div>',
                '      <div class="col-md-2"><input id="schedShift" class="form-control" placeholder="Shift Code"></div>',
                '      <div class="col-md-2"><button id="schedAddBtn" class="btn btn-primary w-100">Assign</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-calendar-week text-primary me-2"></i>Weekly Schedule</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Employee</th><th>Unit</th><th>Day</th><th>Shift</th></tr></thead>',
                '      <tbody>',
                schedules.map(function (item) {
                    return '<tr><td>' + item.employee + '</td><td>' + item.unit + '</td><td>' + item.day + '</td><td><span class="badge bg-primary-subtle text-primary">' + item.shift + '</span></td></tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('schedAddBtn');
            if (!addButton) {
                return;
            }

            addButton.addEventListener('click', function () {
                const employee = (document.getElementById('schedEmployee').value || '').trim();
                const unit = (document.getElementById('schedUnit').value || '').trim();
                const day = (document.getElementById('schedDay').value || '').trim();
                const shift = (document.getElementById('schedShift').value || '').trim().toUpperCase();

                if (!employee || !unit || !day || !shift) {
                    showStaffSchedulingInfo('Incomplete Assignment', 'Complete employee, unit, day, and shift code before assigning.');
                    return;
                }

                schedules.unshift({ employee: employee, unit: unit, day: day, shift: shift });
                setStorageList(STAFF_SCHEDULE_KEY, schedules);
                render();
                showStaffSchedulingInfo('Assignment Added', employee + ' has been assigned to ' + shift + ' on ' + day + '.');
            });
        }

        render();
    };
})(window.HRSubmodules);

(function (registry) {
    const SHIFT_ASSIGNMENT_KEY = 'hospitalHrShiftAssignmentQueue';

    function ensureShiftAssignmentModalHost() {
        if (document.getElementById('shiftAssignmentModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="shiftAssignmentModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="shiftAssignmentModalTitle">Shift Assignment</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="shiftAssignmentModalBody"></div>',
            '      <div class="modal-footer" id="shiftAssignmentModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showShiftAssignmentModal(config) {
        const modalEl = document.getElementById('shiftAssignmentModal');
        const titleEl = document.getElementById('shiftAssignmentModalTitle');
        const bodyEl = document.getElementById('shiftAssignmentModalBody');
        const footerEl = document.getElementById('shiftAssignmentModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderShiftAssignment = function (container) {
        ensureShiftAssignmentModalHost();

        const fallback = [
            { ticket: 'ASG-201', employee: 'Mark Rivera', request: 'Swap PM-8 to AM-8 (Tue)', status: 'Pending' },
            { ticket: 'ASG-202', employee: 'Leah Gomez', request: 'Assign NS-10 (Weekend)', status: 'Pending' },
            { ticket: 'ASG-203', employee: 'Paolo Cruz', request: 'Move to PM-8 (Fri)', status: 'Approved' }
        ];

        let queue = getStorageList(SHIFT_ASSIGNMENT_KEY, fallback);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-people-arrows-left-right text-primary me-2"></i>Shift Assignment Queue</h5>',
                '    <span class="badge bg-warning-subtle text-warning">' + queue.filter(function (item) { return item.status === 'Pending'; }).length + ' Pending</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle shift-assign-submodule">',
                '      <thead><tr><th>Ticket</th><th>Employee</th><th>Request</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                queue.map(function (item) {
                    const badge = item.status === 'Approved' ? 'bg-success-subtle text-success' : item.status === 'Rejected' ? 'bg-danger-subtle text-danger' : 'bg-warning-subtle text-warning';
                    return '<tr>'
                        + '<td>' + item.ticket + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.request + '</td>'
                        + '<td><span class="badge ' + badge + '">' + item.status + '</span></td>'
                        + '<td>'
                        + '<button class="btn btn-sm btn-outline-success me-1" data-action="approve" data-id="' + item.ticket + '">Approve</button>'
                        + '<button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.ticket + '">Reject</button>'
                        + '</td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const action = button.getAttribute('data-action');
                    const ticket = button.getAttribute('data-id');
                    const target = queue.find(function (item) { return item.ticket === ticket; });
                    if (!target) {
                        return;
                    }

                    const nextStatus = action === 'approve' ? 'Approved' : 'Rejected';
                    showShiftAssignmentModal({
                        title: nextStatus === 'Approved' ? 'Approve Shift Request' : 'Reject Shift Request',
                        message: 'Update ' + target.ticket + ' for ' + target.employee + ' to ' + nextStatus + '?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn ' + (nextStatus === 'Approved' ? 'btn-success' : 'btn-danger') + '" id="confirmShiftAssignmentActionBtn">Confirm</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmShiftAssignmentActionBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                queue = queue.map(function (item) {
                                    if (item.ticket !== ticket) {
                                        return item;
                                    }
                                    return {
                                        ticket: item.ticket,
                                        employee: item.employee,
                                        request: item.request,
                                        status: nextStatus
                                    };
                                });

                                setStorageList(SHIFT_ASSIGNMENT_KEY, queue);
                                modal.hide();
                                render();

                                showShiftAssignmentModal({
                                    title: 'Assignment Updated',
                                    message: 'Ticket ' + target.ticket + ' is now ' + nextStatus + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);

(function (registry) {
    const STAFF_SCHEDULE_KEY = 'hospitalHrStaffSchedule';

    function ensureScheduleReportsModalHost() {
        if (document.getElementById('scheduleReportsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="scheduleReportsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="scheduleReportsModalTitle">Schedule Reports</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="scheduleReportsModalBody"></div>',
            '      <div class="modal-footer" id="scheduleReportsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showScheduleReportsModal(config) {
        const modalEl = document.getElementById('scheduleReportsModal');
        const titleEl = document.getElementById('scheduleReportsModalTitle');
        const bodyEl = document.getElementById('scheduleReportsModalBody');
        const footerEl = document.getElementById('scheduleReportsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = (config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    registry.renderScheduleReports = function (container) {
        ensureScheduleReportsModalHost();

        const fallback = [
            { employee: 'Anna Santos', unit: 'HR Ops', day: 'Monday', shift: 'AM-8' },
            { employee: 'Jude Molina', unit: 'Operations', day: 'Monday', shift: 'PM-8' },
            { employee: 'Liza De Leon', unit: 'Nursing', day: 'Monday', shift: 'NS-10' },
            { employee: 'Mark Rivera', unit: 'Finance', day: 'Tuesday', shift: 'AM-8' }
        ];

        const schedules = getStorageList(STAFF_SCHEDULE_KEY, fallback);
        const byShift = {};
        schedules.forEach(function (row) {
            byShift[row.shift] = (byShift[row.shift] || 0) + 1;
        });

        const summaryRows = Object.keys(byShift).map(function (shiftCode) {
            return '<tr><td>' + shiftCode + '</td><td>' + byShift[shiftCode] + '</td></tr>';
        }).join('');

        container.innerHTML = [
            '<div class="d-flex justify-content-between align-items-center mb-3 schedule-reports-submodule">',
            '  <h6 class="mb-0"><i class="fas fa-file-chart-column text-primary me-2"></i>Schedule Reports</h6>',
            '  <button id="exportScheduleCsv" class="btn btn-outline-secondary btn-sm">Export CSV</button>',
            '</div>',
            '<div class="row g-3 mb-3">',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Assignments</p><h5 class="mb-0">' + schedules.length + '</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Unique Shift Types</p><h5 class="mb-0">' + Object.keys(byShift).length + '</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Coverage Days</p><h5 class="mb-0">7</h5></div></div>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-chart-simple text-primary me-2"></i>Shift Distribution</h5></div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>Shift Code</th><th>Assigned Staff</th></tr></thead>',
            '      <tbody>' + summaryRows + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');

        const exportButton = document.getElementById('exportScheduleCsv');
        if (exportButton) {
            exportButton.addEventListener('click', function () {
                showScheduleReportsModal({
                    title: 'Export Schedule CSV',
                    message: 'Download the full staff schedule report as CSV?',
                    footerHtml: [
                        '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                        '<button type="button" class="btn btn-primary" id="confirmScheduleExportBtn">Export</button>'
                    ].join(''),
                    onShown: function (modal) {
                        const confirmBtn = document.getElementById('confirmScheduleExportBtn');
                        if (!confirmBtn) {
                            return;
                        }

                        confirmBtn.addEventListener('click', function () {
                            const csvLines = ['Employee,Unit,Day,Shift'];
                            schedules.forEach(function (row) {
                                csvLines.push([row.employee, row.unit, row.day, row.shift].join(','));
                            });

                            const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
                            const link = document.createElement('a');
                            link.href = URL.createObjectURL(blob);
                            link.download = 'schedule-reports.csv';
                            link.click();
                            URL.revokeObjectURL(link.href);
                            modal.hide();

                            showScheduleReportsModal({
                                title: 'Export Complete',
                                message: 'Schedule report CSV has been downloaded.'
                            });
                        }, { once: true });
                    }
                });
            });
        }
    };
})(window.HRSubmodules);

(function () {
    var container = document.getElementById('ssmSubmoduleContainer');
    var buttons = Array.prototype.slice.call(document.querySelectorAll('button[data-submodule]'));

    var rendererMap = {
        'Shift Creation': 'renderShiftCreation',
        'Staff Scheduling': 'renderStaffScheduling',
        'Shift Assignment': 'renderShiftAssignment',
        'Schedule Reports': 'renderScheduleReports'
    };

    function setActiveButton(activeName) {
        buttons.forEach(function (button) {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(submoduleName) {
        if (!container) {
            return;
        }

        var rendererName = rendererMap[submoduleName];
        var renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            renderer(container);
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer is not available.</div>';
        }

        setActiveButton(submoduleName);
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            renderSubmodule(button.getAttribute('data-submodule'));
        });
    });

    renderSubmodule('Shift Creation');
})();
