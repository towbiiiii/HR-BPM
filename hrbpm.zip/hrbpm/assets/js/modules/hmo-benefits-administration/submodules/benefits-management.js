window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const BENEFITS_KEY = 'hospitalHrBenefitsRecords';

    function ensureBenefitsManagementModalHost() {
        if (document.getElementById('benefitsManagementModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="benefitsManagementModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="benefitsManagementModalTitle">Benefits Management</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="benefitsManagementModalBody"></div>',
            '      <div class="modal-footer" id="benefitsManagementModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showBenefitsManagementModal(config) {
        const modalEl = document.getElementById('benefitsManagementModal');
        const titleEl = document.getElementById('benefitsManagementModalTitle');
        const bodyEl = document.getElementById('benefitsManagementModalBody');
        const footerEl = document.getElementById('benefitsManagementModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultBenefits() {
        return [
            { id: 'BEN-6001', employee: 'Anna Santos', hmoPlan: 'Premium Plus', benefitsType: 'Medical', coverage: 250000, claimAmount: 0, claimStatus: 'None', enrolled: true },
            { id: 'BEN-6002', employee: 'Jude Molina', hmoPlan: 'Standard Care', benefitsType: 'Medical', coverage: 180000, claimAmount: 12000, claimStatus: 'Approved', enrolled: true },
            { id: 'BEN-6003', employee: 'Leah Gomez', hmoPlan: 'Basic Care', benefitsType: 'Medical', coverage: 120000, claimAmount: 8000, claimStatus: 'Pending', enrolled: true }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderBenefitsManagement = function (container) {
        ensureBenefitsManagementModalHost();

        let records = getStorageList(BENEFITS_KEY, defaultBenefits);

        function render() {
            const totalCoverage = records.reduce(function (sum, item) { return sum + Number(item.coverage || 0); }, 0);

            container.innerHTML = [
                '<div class="row g-3 mb-3 benefits-management-submodule">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Benefit Profiles</p><h5 class="mb-0">' + records.length + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Coverage</p><h5 class="mb-0">₱' + totalCoverage.toLocaleString() + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Medical Plans</p><h5 class="mb-0">' + records.filter(function (item) { return item.benefitsType === 'Medical'; }).length + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-shield-heart text-primary me-2"></i>Benefits Management</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Plan</th><th>Coverage</th><th>Benefit Type</th><th>Action</th></tr></thead>',
                '      <tbody>',
                records.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.hmoPlan + '</td>'
                        + '<td>₱' + Number(item.coverage || 0).toLocaleString() + '</td>'
                        + '<td>' + item.benefitsType + '</td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="upgrade" data-id="' + item.id + '">+₱10,000</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="upgrade"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = records.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showBenefitsManagementModal({
                        title: 'Upgrade Coverage',
                        message: 'Increase coverage for ' + target.employee + ' by ₱10,000?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmBenefitsUpgradeBtn">Upgrade</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmBenefitsUpgradeBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                records = records.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        hmoPlan: item.hmoPlan,
                                        benefitsType: item.benefitsType,
                                        coverage: Number(item.coverage || 0) + 10000,
                                        claimAmount: item.claimAmount,
                                        claimStatus: item.claimStatus,
                                        enrolled: item.enrolled
                                    };
                                });

                                setStorageList(BENEFITS_KEY, records);
                                modal.hide();
                                render();

                                showBenefitsManagementModal({
                                    title: 'Coverage Updated',
                                    message: 'Coverage upgrade was applied for ' + target.employee + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);
