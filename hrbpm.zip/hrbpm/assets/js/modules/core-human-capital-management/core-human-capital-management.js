
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const EMPLOYEES_KEY = 'hospitalHrHcmEmployees';

    function ensureEmployeeMasterDataModalHost() {
        if (document.getElementById('employeeMasterDataModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="employeeMasterDataModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="employeeMasterDataModalTitle">Employee Master Data</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="employeeMasterDataModalBody"></div>',
            '      <div class="modal-footer" id="employeeMasterDataModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showEmployeeMasterDataInfo(title, message) {
        const modalEl = document.getElementById('employeeMasterDataModal');
        const titleEl = document.getElementById('employeeMasterDataModalTitle');
        const bodyEl = document.getElementById('employeeMasterDataModalBody');
        const footerEl = document.getElementById('employeeMasterDataModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function defaultEmployees() {
        return [
            { id: 'EMP-1001', name: 'Anna Santos', department: 'Human Resources', position: 'HR Specialist', status: 'Active' },
            { id: 'EMP-1002', name: 'Jude Molina', department: 'Operations', position: 'Operations Officer', status: 'Active' },
            { id: 'EMP-1003', name: 'Leah Gomez', department: 'Finance', position: 'Payroll Analyst', status: 'Probation' }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();

        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderEmployeeMasterData = function (container) {
        ensureEmployeeMasterDataModalHost();

        let employees = getStorageList(EMPLOYEES_KEY, defaultEmployees);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 employee-master-data-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-id-badge text-primary me-2"></i>Create Employee Master Record</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-3"><input id="hcmEmpName" class="form-control" placeholder="Full Name"></div>',
                '      <div class="col-md-3"><input id="hcmEmpDepartment" class="form-control" placeholder="Department"></div>',
                '      <div class="col-md-3"><input id="hcmEmpPosition" class="form-control" placeholder="Position"></div>',
                '      <div class="col-md-2">',
                '        <select id="hcmEmpStatus" class="form-select">',
                '          <option>Active</option><option>Probation</option><option>Inactive</option>',
                '        </select>',
                '      </div>',
                '      <div class="col-md-1"><button id="hcmEmpAddBtn" class="btn btn-primary w-100">Add</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-database text-primary me-2"></i>Employee Master Data</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Employee ID</th><th>Name</th><th>Department</th><th>Position</th><th>Status</th></tr></thead>',
                '      <tbody>',
                employees.map(function (item) {
                    const badge = item.status === 'Active'
                        ? 'bg-success-subtle text-success'
                        : item.status === 'Probation'
                            ? 'bg-warning-subtle text-warning'
                            : 'bg-secondary-subtle text-secondary';
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.name + '</td>'
                        + '<td>' + item.department + '</td>'
                        + '<td>' + item.position + '</td>'
                        + '<td><span class="badge ' + badge + '">' + item.status + '</span></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('hcmEmpAddBtn');
            if (!addButton) {
                return;
            }

            addButton.addEventListener('click', function () {
                const name = (document.getElementById('hcmEmpName').value || '').trim();
                const department = (document.getElementById('hcmEmpDepartment').value || '').trim();
                const position = (document.getElementById('hcmEmpPosition').value || '').trim();
                const status = (document.getElementById('hcmEmpStatus').value || 'Active').trim();

                if (!name || !department || !position) {
                    showEmployeeMasterDataInfo('Incomplete Record', 'Name, department, and position are required to add a master record.');
                    return;
                }

                const nextId = 'EMP-' + (1000 + employees.length + 1);
                employees.unshift({
                    id: nextId,
                    name: name,
                    department: department,
                    position: position,
                    status: status
                });

                setStorageList(EMPLOYEES_KEY, employees);
                render();
                showEmployeeMasterDataInfo('Record Added', 'Employee record ' + nextId + ' for ' + name + ' was created.');
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const EMPLOYMENT_RECORDS_KEY = 'hospitalHrHcmEmploymentRecords';

    function ensureEmploymentRecordsModalHost() {
        if (document.getElementById('employmentRecordsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="employmentRecordsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="employmentRecordsModalTitle">Employment Records</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="employmentRecordsModalBody"></div>',
            '      <div class="modal-footer" id="employmentRecordsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showEmploymentRecordsModal(config) {
        const modalEl = document.getElementById('employmentRecordsModal');
        const titleEl = document.getElementById('employmentRecordsModalTitle');
        const bodyEl = document.getElementById('employmentRecordsModalBody');
        const footerEl = document.getElementById('employmentRecordsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultRecords() {
        return [
            { id: 'REC-5001', employee: 'Anna Santos', recordType: 'Regularization', effectiveDate: '2026-03-05', status: 'Pending' },
            { id: 'REC-5002', employee: 'Jude Molina', recordType: 'Promotion', effectiveDate: '2026-03-08', status: 'Approved' },
            { id: 'REC-5003', employee: 'Leah Gomez', recordType: 'Transfer', effectiveDate: '2026-03-12', status: 'Pending' }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();

        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderEmploymentRecords = function (container) {
        ensureEmploymentRecordsModalHost();

        let records = getStorageList(EMPLOYMENT_RECORDS_KEY, defaultRecords);

        function render() {
            const pending = records.filter(function (item) { return item.status === 'Pending'; }).length;
            const approved = records.filter(function (item) { return item.status === 'Approved'; }).length;

            container.innerHTML = [
                '<div class="row g-3 mb-3 employment-records-submodule">',
                '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Records</p><h5 class="mb-0">' + records.length + '</h5></div></div>',
                '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Pending</p><h5 class="mb-0">' + pending + '</h5></div></div>',
                '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Approved</p><h5 class="mb-0">' + approved + '</h5></div></div>',
                '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Action Queue</p><h5 class="mb-0">' + pending + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-folder-tree text-primary me-2"></i>Employment Records</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Record ID</th><th>Employee</th><th>Type</th><th>Effective Date</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                records.map(function (item) {
                    const badge = item.status === 'Approved'
                        ? 'bg-success-subtle text-success'
                        : item.status === 'Rejected'
                            ? 'bg-danger-subtle text-danger'
                            : 'bg-warning-subtle text-warning';

                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.recordType + '</td>'
                        + '<td>' + item.effectiveDate + '</td>'
                        + '<td><span class="badge ' + badge + '">' + item.status + '</span></td>'
                        + '<td>'
                        + '<button class="btn btn-sm btn-outline-success me-1" data-action="approve" data-id="' + item.id + '">Approve</button>'
                        + '<button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.id + '">Reject</button>'
                        + '</td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const action = button.getAttribute('data-action');
                    const target = records.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    const nextStatus = action === 'approve' ? 'Approved' : 'Rejected';
                    showEmploymentRecordsModal({
                        title: nextStatus === 'Approved' ? 'Approve Record' : 'Reject Record',
                        message: 'Set employment record ' + target.id + ' for ' + target.employee + ' to ' + nextStatus + '?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn ' + (nextStatus === 'Approved' ? 'btn-success' : 'btn-danger') + '" id="confirmEmploymentRecordActionBtn">Confirm</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmEmploymentRecordActionBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                records = records.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }

                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        recordType: item.recordType,
                                        effectiveDate: item.effectiveDate,
                                        status: nextStatus
                                    };
                                });

                                setStorageList(EMPLOYMENT_RECORDS_KEY, records);
                                modal.hide();
                                render();

                                showEmploymentRecordsModal({
                                    title: 'Record Updated',
                                    message: 'Employment record ' + target.id + ' is now ' + nextStatus + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const POSITIONS_KEY = 'hospitalHrHcmPositions';

    function ensurePositionManagementModalHost() {
        if (document.getElementById('positionManagementModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="positionManagementModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="positionManagementModalTitle">Position Management</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="positionManagementModalBody"></div>',
            '      <div class="modal-footer" id="positionManagementModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showPositionManagementModal(config) {
        const modalEl = document.getElementById('positionManagementModal');
        const titleEl = document.getElementById('positionManagementModalTitle');
        const bodyEl = document.getElementById('positionManagementModalBody');
        const footerEl = document.getElementById('positionManagementModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultPositions() {
        return [
            { id: 'POS-301', title: 'HR Manager', department: 'Human Resources', headcount: 1, filled: 1 },
            { id: 'POS-302', title: 'Payroll Analyst', department: 'Finance', headcount: 2, filled: 1 },
            { id: 'POS-303', title: 'Clinic Coordinator', department: 'Operations', headcount: 1, filled: 0 }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();

        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderPositionManagement = function (container) {
        ensurePositionManagementModalHost();

        let positions = getStorageList(POSITIONS_KEY, defaultPositions);

        function render() {
            const openCount = positions.filter(function (item) { return Number(item.filled) < Number(item.headcount); }).length;

            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 position-management-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-briefcase text-primary me-2"></i>Create Position</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-4"><input id="hcmPosTitle" class="form-control" placeholder="Position Title"></div>',
                '      <div class="col-md-3"><input id="hcmPosDepartment" class="form-control" placeholder="Department"></div>',
                '      <div class="col-md-2"><input id="hcmPosHeadcount" type="number" min="1" class="form-control" placeholder="Headcount"></div>',
                '      <div class="col-md-2"><input id="hcmPosFilled" type="number" min="0" class="form-control" placeholder="Filled"></div>',
                '      <div class="col-md-1"><button id="hcmPosAddBtn" class="btn btn-primary w-100">Add</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-sitemap text-primary me-2"></i>Position Management</h5>',
                '    <span class="badge bg-warning-subtle text-warning">' + openCount + ' Open Positions</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Position ID</th><th>Title</th><th>Department</th><th>Headcount</th><th>Filled</th><th>Action</th></tr></thead>',
                '      <tbody>',
                positions.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.title + '</td>'
                        + '<td>' + item.department + '</td>'
                        + '<td>' + item.headcount + '</td>'
                        + '<td>' + item.filled + '</td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="fill" data-id="' + item.id + '">Add Occupant</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('hcmPosAddBtn');
            if (addButton) {
                addButton.addEventListener('click', function () {
                    const title = (document.getElementById('hcmPosTitle').value || '').trim();
                    const department = (document.getElementById('hcmPosDepartment').value || '').trim();
                    const headcount = Number(document.getElementById('hcmPosHeadcount').value || 0);
                    const filled = Number(document.getElementById('hcmPosFilled').value || 0);

                    if (!title || !department || !headcount) {
                        showPositionManagementModal({
                            title: 'Incomplete Position',
                            message: 'Provide position title, department, and headcount before adding.'
                        });
                        return;
                    }

                    const nextId = 'POS-' + (300 + positions.length + 1);
                    positions.unshift({
                        id: nextId,
                        title: title,
                        department: department,
                        headcount: headcount,
                        filled: filled > headcount ? headcount : filled
                    });

                    setStorageList(POSITIONS_KEY, positions);
                    render();
                    showPositionManagementModal({
                        title: 'Position Added',
                        message: 'Position ' + nextId + ' (' + title + ') has been created.'
                    });
                });
            }

            container.querySelectorAll('button[data-action="fill"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = positions.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showPositionManagementModal({
                        title: 'Add Occupant',
                        message: 'Increase filled count for ' + target.id + ' (' + target.title + ')?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmPositionFillBtn">Confirm</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmPositionFillBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                positions = positions.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }

                                    const nextFilled = Number(item.filled) + 1;
                                    return {
                                        id: item.id,
                                        title: item.title,
                                        department: item.department,
                                        headcount: item.headcount,
                                        filled: nextFilled > Number(item.headcount) ? Number(item.headcount) : nextFilled
                                    };
                                });

                                setStorageList(POSITIONS_KEY, positions);
                                modal.hide();
                                render();

                                showPositionManagementModal({
                                    title: 'Occupant Added',
                                    message: 'Filled count for ' + target.id + ' has been updated.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const EMPLOYEES_KEY = 'hospitalHrHcmEmployees';
    const POSITIONS_KEY = 'hospitalHrHcmPositions';

    function defaultEmployees() {
        return [
            { id: 'EMP-1001', name: 'Anna Santos', department: 'Human Resources', position: 'HR Specialist', status: 'Active' },
            { id: 'EMP-1002', name: 'Jude Molina', department: 'Operations', position: 'Operations Officer', status: 'Active' },
            { id: 'EMP-1003', name: 'Leah Gomez', department: 'Finance', position: 'Payroll Analyst', status: 'Probation' }
        ];
    }

    function defaultPositions() {
        return [
            { id: 'POS-301', title: 'HR Manager', department: 'Human Resources', headcount: 1, filled: 1 },
            { id: 'POS-302', title: 'Payroll Analyst', department: 'Finance', headcount: 2, filled: 1 },
            { id: 'POS-303', title: 'Clinic Coordinator', department: 'Operations', headcount: 1, filled: 0 }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();

        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    registry.renderOrganizationalStructure = function (container) {
        const employees = getStorageList(EMPLOYEES_KEY, defaultEmployees);
        const positions = getStorageList(POSITIONS_KEY, defaultPositions);

        const departmentMap = employees.reduce(function (acc, employee) {
            const key = employee.department || 'Unassigned';
            if (!acc[key]) {
                acc[key] = { department: key, employees: 0, active: 0 };
            }
            acc[key].employees += 1;
            if (employee.status === 'Active') {
                acc[key].active += 1;
            }
            return acc;
        }, {});

        const positionMap = positions.reduce(function (acc, position) {
            const key = position.department || 'Unassigned';
            if (!acc[key]) {
                acc[key] = { headcount: 0, filled: 0 };
            }
            acc[key].headcount += Number(position.headcount || 0);
            acc[key].filled += Number(position.filled || 0);
            return acc;
        }, {});

        const rows = Object.keys(departmentMap).sort().map(function (departmentName) {
            const employeeStats = departmentMap[departmentName];
            const positionStats = positionMap[departmentName] || { headcount: 0, filled: 0 };
            const openSlots = positionStats.headcount - positionStats.filled;

            return '<tr>'
                + '<td>' + departmentName + '</td>'
                + '<td>' + employeeStats.employees + '</td>'
                + '<td>' + employeeStats.active + '</td>'
                + '<td>' + positionStats.headcount + '</td>'
                + '<td>' + positionStats.filled + '</td>'
                + '<td>' + (openSlots > 0 ? openSlots : 0) + '</td>'
                + '</tr>';
        }).join('');

        const totalHeadcount = positions.reduce(function (sum, item) { return sum + Number(item.headcount || 0); }, 0);
        const totalFilled = positions.reduce(function (sum, item) { return sum + Number(item.filled || 0); }, 0);

        container.innerHTML = [
            '<div class="row g-3 mb-3 organizational-structure-submodule">',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Departments</p><h5 class="mb-0">' + Object.keys(departmentMap).length + '</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Headcount Plan</p><h5 class="mb-0">' + totalHeadcount + '</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Filled Positions</p><h5 class="mb-0">' + totalFilled + '</h5></div></div>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-building-user text-primary me-2"></i>Organizational Structure Matrix</h5></div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>Department</th><th>Employees</th><th>Active</th><th>Headcount Plan</th><th>Filled</th><th>Open Slots</th></tr></thead>',
            '      <tbody>' + rows + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');
    };
})(window.HRSubmodules);

(function () {
    var container = document.getElementById('hcmSubmoduleContainer');
    var buttons = Array.prototype.slice.call(document.querySelectorAll('button[data-submodule]'));

    var rendererMap = {
        'Employee Master Data': 'renderEmployeeMasterData',
        'Employment Records': 'renderEmploymentRecords',
        'Position Management': 'renderPositionManagement',
        'Organizational Structure': 'renderOrganizationalStructure'
    };

    function setActiveButton(activeName) {
        buttons.forEach(function (button) {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(submoduleName) {
        if (!container) {
            return;
        }

        var rendererName = rendererMap[submoduleName];
        var renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            renderer(container);
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer is not available.</div>';
        }

        setActiveButton(submoduleName);
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            renderSubmodule(button.getAttribute('data-submodule'));
        });
    });

    if (container && buttons.length) {
        renderSubmodule('Employee Master Data');
    }
})();
