<?php
// php/leave-request-api.php
// Complete fixed version for your database structure

// Start output buffering to catch any errors
ob_start();

require_once __DIR__ . '/connect.php';

// Clear any output that might have been created
ob_clean();

header('Content-Type: application/json');

// Get the request method
$method = $_SERVER['REQUEST_METHOD'];

try {
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    switch ($method) {
        case 'GET':
            // Get all leave requests
            $sql = "SELECT 
                        leave_id,
                        employee_id,
                        employee_name,
                        leave_type,
                        start_date,
                        end_date,
                        leave_reason,
                        leave_status,
                        approved_by,
                        approval_date
                    FROM leave_requests 
                    ORDER BY leave_id DESC";
            
            $stmt = $conn->query($sql);
            
            if (!$stmt) {
                $error = $conn->errorInfo();
                throw new Exception("Query failed: " . ($error[2] ?? 'Unknown error'));
            }
            
            $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Format the data
            $formattedRequests = array();
            foreach ($requests as $row) {
                // Calculate days between dates
                $days = calculateDays($row['start_date'], $row['end_date']);
                
                $formattedRequests[] = [
                    'id' => 'LV-' . $row['leave_id'],
                    'employee' => $row['employee_name'] ?? 'Unknown Employee',
                    'type' => $row['leave_type'] ?? 'Vacation',
                    'from' => $row['start_date'],
                    'to' => $row['end_date'],
                    'days' => $days,
                    'reason' => $row['leave_reason'] ?? '',
                    'status' => $row['leave_status'] ?? 'Pending'
                ];
            }
            
            echo json_encode(['success' => true, 'data' => $formattedRequests]);
            break;
            
        case 'POST':
            // Create a new leave request
            $input = file_get_contents('php://input');
            $data = json_decode($input, true);
            
            if (!$data) {
                throw new Exception('Invalid JSON data received');
            }
            
            // Log the received data for debugging
            error_log('Received POST data: ' . print_r($data, true));
            
            // Validate required fields
            if (empty($data['employee'])) {
                throw new Exception('Employee name is required');
            }
            if (empty($data['type'])) {
                throw new Exception('Leave type is required');
            }
            if (empty($data['from'])) {
                throw new Exception('Start date is required');
            }
            if (empty($data['to'])) {
                throw new Exception('End date is required');
            }
            
            // Start transaction
            $conn->beginTransaction();
            
            try {
                // IMPORTANT: Find or create employee to get employee_id
                $employee_id = null;
                $employee_name = trim($data['employee']);
                
                // Split name for searching
                $nameParts = explode(' ', $employee_name, 2);
                $firstName = $nameParts[0];
                $lastName = isset($nameParts[1]) ? $nameParts[1] : '';
                
                // Try to find existing employee
                if (!empty($firstName) && !empty($lastName)) {
                    $stmt = $conn->prepare("SELECT employee_id, first_name, last_name FROM employees WHERE first_name = ? AND last_name = ? LIMIT 1");
                    $stmt->execute([$firstName, $lastName]);
                } else {
                    // Try searching by full name
                    $stmt = $conn->prepare("SELECT employee_id, first_name, last_name FROM employees WHERE CONCAT(first_name, ' ', last_name) = ? LIMIT 1");
                    $stmt->execute([$employee_name]);
                }
                
                $employee = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($employee) {
                    $employee_id = $employee['employee_id'];
                    error_log("Found existing employee with ID: " . $employee_id);
                } else {
                    // Create new employee if not found
                    error_log("Employee not found, creating new record for: " . $employee_name);
                    
                    // Get default department (first available)
                    $deptStmt = $conn->query("SELECT department_id FROM departments LIMIT 1");
                    $dept = $deptStmt ? $deptStmt->fetch(PDO::FETCH_ASSOC) : null;
                    $deptId = $dept ? $dept['department_id'] : 1;
                    
                    // Get default position (first available)
                    $posStmt = $conn->query("SELECT position_id FROM positions LIMIT 1");
                    $pos = $posStmt ? $posStmt->fetch(PDO::FETCH_ASSOC) : null;
                    $posId = $pos ? $pos['position_id'] : 1;
                    
                    // Create email from name
                    $email = strtolower(str_replace(' ', '.', $employee_name)) . '@hospital.com';
                    
                    // Insert new employee
                    $insertSql = "INSERT INTO employees (
                        first_name, 
                        last_name, 
                        department_id, 
                        position_id, 
                        hire_date, 
                        email, 
                        employment_status
                    ) VALUES (?, ?, ?, ?, CURDATE(), ?, 'Probationary')";
                    
                    $insertStmt = $conn->prepare($insertSql);
                    $insertResult = $insertStmt->execute([
                        $firstName ?: $employee_name,
                        $lastName ?: 'Unknown',
                        $deptId,
                        $posId,
                        $email
                    ]);
                    
                    if (!$insertResult) {
                        $error = $insertStmt->errorInfo();
                        throw new Exception('Failed to create employee: ' . ($error[2] ?? 'Unknown error'));
                    }
                    
                    $employee_id = $conn->lastInsertId();
                    error_log("Created new employee with ID: " . $employee_id);
                }
                
                // Now insert leave request with employee_id
                $sql = "INSERT INTO leave_requests (
                            employee_id,
                            employee_name, 
                            leave_type, 
                            start_date, 
                            end_date, 
                            leave_reason, 
                            leave_status
                        ) VALUES (?, ?, ?, ?, ?, ?, 'Pending')";
                
                $stmt = $conn->prepare($sql);
                $result = $stmt->execute([
                    $employee_id,
                    $employee_name,
                    $data['type'],
                    $data['from'],
                    $data['to'],
                    $data['reason'] ?? ''
                ]);
                
                if (!$result) {
                    $error = $stmt->errorInfo();
                    throw new Exception('Failed to insert leave request: ' . ($error[2] ?? 'Unknown error'));
                }
                
                $leave_id = $conn->lastInsertId();
                
                // Commit transaction
                $conn->commit();
                
                // Calculate days for response
                $days = calculateDays($data['from'], $data['to']);
                
                echo json_encode([
                    'success' => true, 
                    'message' => 'Leave request created successfully',
                    'data' => [
                        'id' => 'LV-' . $leave_id,
                        'employee' => $employee_name,
                        'type' => $data['type'],
                        'from' => $data['from'],
                        'to' => $data['to'],
                        'days' => $days,
                        'reason' => $data['reason'] ?? '',
                        'status' => 'Pending'
                    ]
                ]);
                
            } catch (Exception $e) {
                $conn->rollBack();
                throw $e;
            }
            break;
            
        case 'PUT':
            // Update leave request status
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['id']) || !isset($data['status'])) {
                throw new Exception('Invalid request data');
            }
            
            $leave_id = str_replace('LV-', '', $data['id']);
            
            $sql = "UPDATE leave_requests SET 
                    leave_status = ?, 
                    approval_date = CURDATE()";
            
            $params = [$data['status']];
            
            if (isset($data['approved_by'])) {
                $sql .= ", approved_by = ?";
                $params[] = $data['approved_by'];
            }
            
            $sql .= " WHERE leave_id = ?";
            $params[] = $leave_id;
            
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            
            echo json_encode(['success' => true, 'message' => 'Leave request updated successfully']);
            break;
            
        case 'DELETE':
            // Delete a leave request
            $id = isset($_GET['id']) ? str_replace('LV-', '', $_GET['id']) : null;
            
            if (!$id) {
                throw new Exception('Invalid request ID');
            }
            
            $sql = "DELETE FROM leave_requests WHERE leave_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$id]);
            
            echo json_encode(['success' => true, 'message' => 'Leave request deleted successfully']);
            break;
            
        default:
            throw new Exception('Method not allowed');
    }
} catch (Exception $e) {
    error_log('Leave request API error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}

function calculateDays($from, $to) {
    if (!$from || !$to) return 1;
    
    try {
        $fromDate = new DateTime($from);
        $toDate = new DateTime($to);
        $interval = $fromDate->diff($toDate);
        return max(1, $interval->days + 1);
    } catch (Exception $e) {
        return 1;
    }
}
?>