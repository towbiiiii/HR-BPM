/**
 * Applicant List Submodule
 * Scoped: Human Resources Department
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};

    window.HRSubmodules.renderApplicantList = function (container) {
        const hrApplicants = [
            { id: "HR-2026-001", name: "Clarice Starling", role: "HR Generalist", date: "Mar 01, 2026", status: "New", email: "c.starling@hospital.com", exp: "5 years" },
            { id: "HR-2026-002", name: "Harvey Specter", role: "Recruitment Lead", date: "Feb 28, 2026", status: "Interview", email: "h.specter@hospital.com", exp: "8 years" },
            { id: "HR-2026-003", name: "Donna Paulsen", role: "Benefits Admin", date: "Feb 25, 2026", status: "Shortlisted", email: "d.paulsen@hospital.com", exp: "10 years" },
            { id: "HR-2026-004", name: "Mike Ross", role: "HR Coordinator", date: "Mar 02, 2026", status: "New", email: "m.ross@hospital.com", exp: "2 years" }
        ];

        ensureApplicantModalHost();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-actionbar d-flex justify-content-between align-items-center mb-4">
                    <div class="d-flex gap-2">
                        <div class="search-wrapper">
                            <i class="fas fa-search search-icon"></i>
                            <input type="text" id="hrAppSearch" class="form-control form-control-sm ps-5" placeholder="Search by name or role..." style="width: 300px;">
                        </div>
                        <select class="form-select form-select-sm" id="hrStatusFilter" style="width: 150px;">
                            <option value="all">All Statuses</option>
                            <option value="New">New</option>
                            <option value="Interview">Interviewing</option>
                            <option value="Shortlisted">Shortlisted</option>
                        </select>
                    </div>
                    <button class="btn btn-primary btn-sm px-3" id="btnExternalHire">
                        <i class="fas fa-user-plus me-2"></i>External Hire
                    </button>
                </div>

                <div class="border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th class="ps-4">Candidate Information</th>
                                <th>Position Applied</th>
                                <th>Experience</th>
                                <th>Application Date</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Management</th>
                            </tr>
                        </thead>
                        <tbody id="hrApplicantTableBody">
                            ${generateRows(hrApplicants)}
                        </tbody>
                    </table>
                </div>
            </div>
        `;

        // Interaction Logic
        const searchInput = document.getElementById('hrAppSearch');
        const filterSelect = document.getElementById('hrStatusFilter');

        const updateTable = () => {
            const term = searchInput.value.toLowerCase();
            const status = filterSelect.value;
            const filtered = hrApplicants.filter(a => {
                const matchName = a.name.toLowerCase().includes(term) || a.role.toLowerCase().includes(term);
                const matchStatus = status === 'all' || a.status === status;
                return matchName && matchStatus;
            });
            document.getElementById('hrApplicantTableBody').innerHTML = generateRows(filtered);
        };

        searchInput.addEventListener('input', updateTable);
        filterSelect.addEventListener('change', updateTable);

        const externalHireBtn = document.getElementById('btnExternalHire');
        if (externalHireBtn) {
            externalHireBtn.addEventListener('click', function () {
                openAddApplicantModal(function (newApplicant) {
                    hrApplicants.unshift(newApplicant);
                    updateTable();
                });
            });
        }

        const tableBody = document.getElementById('hrApplicantTableBody');
        if (tableBody) {
            tableBody.addEventListener('click', function (event) {
                const trigger = event.target.closest('button[data-action]');
                if (!trigger) {
                    return;
                }

                const applicantId = trigger.getAttribute('data-id');
                const action = trigger.getAttribute('data-action');
                const applicant = hrApplicants.find(function (item) {
                    return item.id === applicantId;
                });

                if (!applicant) {
                    return;
                }

                if (action === 'view') {
                    openApplicantDetailsModal(applicant);
                    return;
                }

                if (action === 'schedule') {
                    openApplicantScheduleModal(applicant);
                }
            });
        }
    };

    function generateRows(data) {
        if (data.length === 0) return '<tr><td colspan="6" class="text-center py-5 text-muted">No candidates match your criteria</td></tr>';
        
        return data.map(app => `
            <tr>
                <td class="ps-4">
                    <div class="d-flex align-items-center">
                        <div class="applicant-init-avatar me-3">${app.name.charAt(0)}</div>
                        <div>
                            <div class="fw-semibold text-dark mb-0">${app.name}</div>
                            <div class="text-muted extra-small">${app.email}</div>
                        </div>
                    </div>
                </td>
                <td><span class="text-dark fw-medium">${app.role}</span></td>
                <td><span class="text-muted small">${app.exp}</span></td>
                <td class="text-muted small">${app.date}</td>
                <td>${getStatusBadge(app.status)}</td>
                <td class="text-end pe-4">
                    <button class="btn btn-icon-sm me-1" title="View Profile" data-action="view" data-id="${app.id}"><i class="fas fa-file-invoice text-primary"></i></button>
                    <button class="btn btn-icon-sm" title="Schedule" data-action="schedule" data-id="${app.id}"><i class="fas fa-calendar-alt text-success"></i></button>
                </td>
            </tr>
        `).join('');
    }

    function getStatusBadge(status) {
        const colors = {
            'New': 'bg-info-subtle text-info',
            'Interview': 'bg-warning-subtle text-warning',
            'Shortlisted': 'bg-success-subtle text-success'
        };
        return `<span class="badge ${colors[status] || 'bg-light'} border-0 px-2 py-1">${status}</span>`;
    }

    function ensureApplicantModalHost() {
        if (document.getElementById('hrApplicantModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="hrApplicantModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="hrApplicantModalTitle">Applicant Action</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="hrApplicantModalBody"></div>',
            '      <div class="modal-footer" id="hrApplicantModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function openAddApplicantModal(onCreate) {
        const titleEl = document.getElementById('hrApplicantModalTitle');
        const bodyEl = document.getElementById('hrApplicantModalBody');
        const footerEl = document.getElementById('hrApplicantModalFooter');
        const modalEl = document.getElementById('hrApplicantModal');

        if (!titleEl || !bodyEl || !footerEl || !modalEl) {
            return;
        }

        titleEl.textContent = 'Add External Hire';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Full Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="hrNewName" placeholder="e.g. Alex Rivera">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Position</label>',
            '  <input type="text" class="form-control form-control-sm" id="hrNewRole" placeholder="e.g. HR Analyst">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Email</label>',
            '  <input type="email" class="form-control form-control-sm" id="hrNewEmail" placeholder="name@hospital.com">',
            '</div>'
        ].join('');

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="hrAddApplicantConfirm">Add Applicant</button>'
        ].join('');

        const modal = window.bootstrap && window.bootstrap.Modal
            ? window.bootstrap.Modal.getOrCreateInstance(modalEl)
            : null;

        const confirmBtn = document.getElementById('hrAddApplicantConfirm');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function () {
                const name = (document.getElementById('hrNewName').value || '').trim();
                const role = (document.getElementById('hrNewRole').value || '').trim();
                const email = (document.getElementById('hrNewEmail').value || '').trim();

                if (!name || !role || !email) {
                    return;
                }

                onCreate({
                    id: 'HR-2026-' + String(Math.floor(100 + Math.random() * 900)),
                    name: name,
                    role: role,
                    date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
                    status: 'New',
                    email: email,
                    exp: '0 years'
                });

                if (modal) {
                    modal.hide();
                }
            });
        }

        if (modal) {
            modal.show();
        }
    }

    function openApplicantDetailsModal(applicant) {
        const titleEl = document.getElementById('hrApplicantModalTitle');
        const bodyEl = document.getElementById('hrApplicantModalBody');
        const footerEl = document.getElementById('hrApplicantModalFooter');
        const modalEl = document.getElementById('hrApplicantModal');
        if (!titleEl || !bodyEl || !footerEl || !modalEl) {
            return;
        }

        titleEl.textContent = 'Applicant Profile';
        bodyEl.innerHTML = [
            '<div class="small text-muted mb-2">ID: ' + applicant.id + '</div>',
            '<h6 class="mb-1">' + applicant.name + '</h6>',
            '<p class="mb-1"><strong>Role:</strong> ' + applicant.role + '</p>',
            '<p class="mb-1"><strong>Email:</strong> ' + applicant.email + '</p>',
            '<p class="mb-0"><strong>Status:</strong> ' + applicant.status + '</p>'
        ].join('');
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>';

        if (window.bootstrap && window.bootstrap.Modal) {
            window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
        }
    }

    function openApplicantScheduleModal(applicant) {
        const titleEl = document.getElementById('hrApplicantModalTitle');
        const bodyEl = document.getElementById('hrApplicantModalBody');
        const footerEl = document.getElementById('hrApplicantModalFooter');
        const modalEl = document.getElementById('hrApplicantModal');
        if (!titleEl || !bodyEl || !footerEl || !modalEl) {
            return;
        }

        titleEl.textContent = 'Schedule Interview';
        bodyEl.innerHTML = [
            '<p class="mb-2">Set interview for <strong>' + applicant.name + '</strong>.</p>',
            '<label class="form-label small mb-1">Date & Time</label>',
            '<input type="datetime-local" class="form-control form-control-sm" id="hrScheduleDate">'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-success" id="hrScheduleConfirm">Confirm</button>'
        ].join('');

        const modal = window.bootstrap && window.bootstrap.Modal
            ? window.bootstrap.Modal.getOrCreateInstance(modalEl)
            : null;

        const confirmBtn = document.getElementById('hrScheduleConfirm');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function () {
                const dateValue = document.getElementById('hrScheduleDate').value;
                if (!dateValue) {
                    return;
                }

                if (modal) {
                    modal.hide();
                }
            });
        }

        if (modal) {
            modal.show();
        }
    }
})();