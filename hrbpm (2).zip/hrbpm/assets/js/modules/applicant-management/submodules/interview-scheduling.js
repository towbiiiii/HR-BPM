/**
 * Interview Logic
 * Assets: assets/js/modules/applicant-management/submodules/interview-scheduling.js
 */
(function () {
    'use strict';
    window.HRSubmodules = window.HRSubmodules || {};

    function ensureInterviewFeedbackModal() {
        if (document.getElementById('interviewFeedbackModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="interviewFeedbackModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="interviewFeedbackModalTitle">Interview Scheduling</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="interviewFeedbackModalBody"></div>',
            '      <div class="modal-footer">',
            '        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>',
            '      </div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showInterviewFeedback(title, message) {
        const modalEl = document.getElementById('interviewFeedbackModal');
        const titleEl = document.getElementById('interviewFeedbackModalTitle');
        const bodyEl = document.getElementById('interviewFeedbackModalBody');

        if (!modalEl || !titleEl || !bodyEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderInterviewScheduling = function (container) {
        ensureInterviewFeedbackModal();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="row">
                    <div class="col-md-4">
                        <div class="p-3 border rounded-3 bg-light mb-3">
                            <h6 class="fw-bold">Schedule New</h6>
                            <div class="mb-2">
                                <label class="extra-small fw-bold">Candidate</label>
                                <input type="text" id="intCandidate" class="form-control form-control-sm" placeholder="Name">
                            </div>
                            <div class="mb-2">
                                <label class="extra-small fw-bold">Time Slot</label>
                                <input type="datetime-local" id="intTime" class="form-control form-control-sm">
                            </div>
                            <button id="btnConfirmSchedule" class="btn btn-primary btn-sm w-100 mt-2">Book Interview</button>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="border rounded-3 bg-white p-3">
                            <h6 class="fw-bold mb-3">Today's Schedule</h6>
                            <div id="interviewList">
                                <div class="alert alert-info py-2 extra-small">No interviews scheduled for this time.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.getElementById('btnConfirmSchedule').addEventListener('click', () => {
            const name = document.getElementById('intCandidate').value;
            const time = document.getElementById('intTime').value;

            if(!name || !time) {
                showInterviewFeedback('Missing Required Fields', 'Please fill in candidate name and time slot before booking.');
                return;
            }

            // Real-time Update Logic: Update Dashboard
            const count = parseInt(localStorage.getItem('hospitalHrPendingInterviews') || 0);
            localStorage.setItem('hospitalHrPendingInterviews', count + 1);
            
            // Trigger main.js Sync
            window.dispatchEvent(new Event('storage'));
            
            showInterviewFeedback('Interview Confirmed', 'Interview confirmed for ' + name + ' at ' + time + '. Dashboard metrics have been updated.');
            document.getElementById('intCandidate').value = '';
            document.getElementById('intTime').value = '';
        });
    };
})();