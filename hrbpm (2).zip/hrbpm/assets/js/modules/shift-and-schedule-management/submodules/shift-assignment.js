window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const SHIFT_ASSIGNMENT_KEY = 'hospitalHrShiftAssignmentQueue';

    function ensureShiftAssignmentModalHost() {
        if (document.getElementById('shiftAssignmentModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="shiftAssignmentModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="shiftAssignmentModalTitle">Shift Assignment</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="shiftAssignmentModalBody"></div>',
            '      <div class="modal-footer" id="shiftAssignmentModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showShiftAssignmentModal(config) {
        const modalEl = document.getElementById('shiftAssignmentModal');
        const titleEl = document.getElementById('shiftAssignmentModalTitle');
        const bodyEl = document.getElementById('shiftAssignmentModalBody');
        const footerEl = document.getElementById('shiftAssignmentModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderShiftAssignment = function (container) {
        ensureShiftAssignmentModalHost();

        const fallback = [
            { ticket: 'ASG-201', employee: 'Mark Rivera', request: 'Swap PM-8 to AM-8 (Tue)', status: 'Pending' },
            { ticket: 'ASG-202', employee: 'Leah Gomez', request: 'Assign NS-10 (Weekend)', status: 'Pending' },
            { ticket: 'ASG-203', employee: 'Paolo Cruz', request: 'Move to PM-8 (Fri)', status: 'Approved' }
        ];

        let queue = getStorageList(SHIFT_ASSIGNMENT_KEY, fallback);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-people-arrows-left-right text-primary me-2"></i>Shift Assignment Queue</h5>',
                '    <span class="badge bg-warning-subtle text-warning">' + queue.filter(function (item) { return item.status === 'Pending'; }).length + ' Pending</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle shift-assign-submodule">',
                '      <thead><tr><th>Ticket</th><th>Employee</th><th>Request</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                queue.map(function (item) {
                    const badge = item.status === 'Approved' ? 'bg-success-subtle text-success' : item.status === 'Rejected' ? 'bg-danger-subtle text-danger' : 'bg-warning-subtle text-warning';
                    return '<tr>'
                        + '<td>' + item.ticket + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.request + '</td>'
                        + '<td><span class="badge ' + badge + '">' + item.status + '</span></td>'
                        + '<td>'
                        + '<button class="btn btn-sm btn-outline-success me-1" data-action="approve" data-id="' + item.ticket + '">Approve</button>'
                        + '<button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.ticket + '">Reject</button>'
                        + '</td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const action = button.getAttribute('data-action');
                    const ticket = button.getAttribute('data-id');
                    const target = queue.find(function (item) { return item.ticket === ticket; });
                    if (!target) {
                        return;
                    }

                    const nextStatus = action === 'approve' ? 'Approved' : 'Rejected';
                    showShiftAssignmentModal({
                        title: nextStatus === 'Approved' ? 'Approve Shift Request' : 'Reject Shift Request',
                        message: 'Update ' + target.ticket + ' for ' + target.employee + ' to ' + nextStatus + '?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn ' + (nextStatus === 'Approved' ? 'btn-success' : 'btn-danger') + '" id="confirmShiftAssignmentActionBtn">Confirm</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmShiftAssignmentActionBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                queue = queue.map(function (item) {
                                    if (item.ticket !== ticket) {
                                        return item;
                                    }
                                    return {
                                        ticket: item.ticket,
                                        employee: item.employee,
                                        request: item.request,
                                        status: nextStatus
                                    };
                                });

                                setStorageList(SHIFT_ASSIGNMENT_KEY, queue);
                                modal.hide();
                                render();

                                showShiftAssignmentModal({
                                    title: 'Assignment Updated',
                                    message: 'Ticket ' + target.ticket + ' is now ' + nextStatus + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);
