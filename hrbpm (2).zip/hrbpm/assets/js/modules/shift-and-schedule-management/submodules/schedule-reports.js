window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const STAFF_SCHEDULE_KEY = 'hospitalHrStaffSchedule';

    function ensureScheduleReportsModalHost() {
        if (document.getElementById('scheduleReportsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="scheduleReportsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="scheduleReportsModalTitle">Schedule Reports</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="scheduleReportsModalBody"></div>',
            '      <div class="modal-footer" id="scheduleReportsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showScheduleReportsModal(config) {
        const modalEl = document.getElementById('scheduleReportsModal');
        const titleEl = document.getElementById('scheduleReportsModalTitle');
        const bodyEl = document.getElementById('scheduleReportsModalBody');
        const footerEl = document.getElementById('scheduleReportsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = (config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    registry.renderScheduleReports = function (container) {
        ensureScheduleReportsModalHost();

        const fallback = [
            { employee: 'Anna Santos', unit: 'HR Ops', day: 'Monday', shift: 'AM-8' },
            { employee: 'Jude Molina', unit: 'Operations', day: 'Monday', shift: 'PM-8' },
            { employee: 'Liza De Leon', unit: 'Nursing', day: 'Monday', shift: 'NS-10' },
            { employee: 'Mark Rivera', unit: 'Finance', day: 'Tuesday', shift: 'AM-8' }
        ];

        const schedules = getStorageList(STAFF_SCHEDULE_KEY, fallback);
        const byShift = {};
        schedules.forEach(function (row) {
            byShift[row.shift] = (byShift[row.shift] || 0) + 1;
        });

        const summaryRows = Object.keys(byShift).map(function (shiftCode) {
            return '<tr><td>' + shiftCode + '</td><td>' + byShift[shiftCode] + '</td></tr>';
        }).join('');

        container.innerHTML = [
            '<div class="d-flex justify-content-between align-items-center mb-3 schedule-reports-submodule">',
            '  <h6 class="mb-0"><i class="fas fa-file-chart-column text-primary me-2"></i>Schedule Reports</h6>',
            '  <button id="exportScheduleCsv" class="btn btn-outline-secondary btn-sm">Export CSV</button>',
            '</div>',
            '<div class="row g-3 mb-3">',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Assignments</p><h5 class="mb-0">' + schedules.length + '</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Unique Shift Types</p><h5 class="mb-0">' + Object.keys(byShift).length + '</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Coverage Days</p><h5 class="mb-0">7</h5></div></div>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-chart-simple text-primary me-2"></i>Shift Distribution</h5></div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>Shift Code</th><th>Assigned Staff</th></tr></thead>',
            '      <tbody>' + summaryRows + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');

        const exportButton = document.getElementById('exportScheduleCsv');
        if (exportButton) {
            exportButton.addEventListener('click', function () {
                showScheduleReportsModal({
                    title: 'Export Schedule CSV',
                    message: 'Download the full staff schedule report as CSV?',
                    footerHtml: [
                        '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                        '<button type="button" class="btn btn-primary" id="confirmScheduleExportBtn">Export</button>'
                    ].join(''),
                    onShown: function (modal) {
                        const confirmBtn = document.getElementById('confirmScheduleExportBtn');
                        if (!confirmBtn) {
                            return;
                        }

                        confirmBtn.addEventListener('click', function () {
                            const csvLines = ['Employee,Unit,Day,Shift'];
                            schedules.forEach(function (row) {
                                csvLines.push([row.employee, row.unit, row.day, row.shift].join(','));
                            });

                            const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
                            const link = document.createElement('a');
                            link.href = URL.createObjectURL(blob);
                            link.download = 'schedule-reports.csv';
                            link.click();
                            URL.revokeObjectURL(link.href);
                            modal.hide();

                            showScheduleReportsModal({
                                title: 'Export Complete',
                                message: 'Schedule report CSV has been downloaded.'
                            });
                        }, { once: true });
                    }
                });
            });
        }
    };
})(window.HRSubmodules);
