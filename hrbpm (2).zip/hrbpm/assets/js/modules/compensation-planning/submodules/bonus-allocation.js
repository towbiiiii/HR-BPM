window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const COMPENSATION_KEY = 'hospitalHrCompensationRecords';

    function ensureBonusAllocationModalHost() {
        if (document.getElementById('bonusAllocationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="bonusAllocationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="bonusAllocationModalTitle">Bonus Allocation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="bonusAllocationModalBody"></div>',
            '      <div class="modal-footer" id="bonusAllocationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showBonusAllocationModal(config) {
        const modalEl = document.getElementById('bonusAllocationModal');
        const titleEl = document.getElementById('bonusAllocationModalTitle');
        const bodyEl = document.getElementById('bonusAllocationModalBody');
        const footerEl = document.getElementById('bonusAllocationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultCompensation() {
        return [
            { id: 'CMP-7001', employee: 'Anna Santos', adjustmentType: 'Merit Increase', amount: 2500, effectiveDate: '2026-03-10', status: 'Pending', incentive: 0, bonus: 0 },
            { id: 'CMP-7002', employee: 'Jude Molina', adjustmentType: 'Promotion Increase', amount: 4000, effectiveDate: '2026-03-15', status: 'Approved', incentive: 1500, bonus: 3000 },
            { id: 'CMP-7003', employee: 'Leah Gomez', adjustmentType: 'Market Alignment', amount: 1800, effectiveDate: '2026-03-20', status: 'Pending', incentive: 800, bonus: 0 }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderBonusAllocation = function (container) {
        ensureBonusAllocationModalHost();

        let records = getStorageList(COMPENSATION_KEY, defaultCompensation);

        function render() {
            const totalBonus = records.reduce(function (sum, item) {
                return sum + Number(item.bonus || 0);
            }, 0);

            const approvedCount = records.filter(function (item) {
                return item.status === 'Approved';
            }).length;

            container.innerHTML = [
                '<div class="d-flex justify-content-between align-items-center mb-3 bonus-allocation-submodule">',
                '  <h6 class="mb-0"><i class="fas fa-gift text-primary me-2"></i>Bonus Allocation</h6>',
                '</div>',
                '<div class="row g-3 mb-3">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Approved Profiles</p><h5 class="mb-0">' + approvedCount + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Bonus Pool</p><h5 class="mb-0">₱' + totalBonus.toLocaleString() + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Allocation Cycle</p><h5 class="mb-0">Q1 2026</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-sack-dollar text-primary me-2"></i>Bonus Allocation Register</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Status</th><th>Incentive</th><th>Bonus</th><th>Action</th></tr></thead>',
                '      <tbody>',
                records.map(function (item) {
                    const badge = item.status === 'Approved' ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning';
                    const disabled = item.status !== 'Approved' ? ' disabled' : '';
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td><span class="badge ' + badge + '">' + item.status + '</span></td>'
                        + '<td>₱' + Number(item.incentive || 0).toLocaleString() + '</td>'
                        + '<td>₱' + Number(item.bonus || 0).toLocaleString() + '</td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="allocate" data-id="' + item.id + '"' + disabled + '>+₱1,000 Bonus</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="allocate"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = records.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showBonusAllocationModal({
                        title: 'Allocate Bonus',
                        message: 'Allocate ₱1,000 bonus to ' + target.employee + ' (' + target.id + ')?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmBonusAllocationBtn">Allocate</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmBonusAllocationBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                records = records.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        adjustmentType: item.adjustmentType,
                                        amount: item.amount,
                                        effectiveDate: item.effectiveDate,
                                        status: item.status,
                                        incentive: item.incentive,
                                        bonus: Number(item.bonus || 0) + 1000
                                    };
                                });
                                setStorageList(COMPENSATION_KEY, records);
                                modal.hide();
                                render();

                                showBonusAllocationModal({
                                    title: 'Bonus Allocated',
                                    message: '₱1,000 bonus was allocated for ' + target.employee + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);
