window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const CLAIMS_RECORDS_KEY = 'hospitalHrClaimsRecords';

    function ensureClaimReviewModalHost() {
        if (document.getElementById('claimReviewModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="claimReviewModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="claimReviewModalTitle">Claim Review</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="claimReviewModalBody"></div>',
            '      <div class="modal-footer" id="claimReviewModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showClaimReviewModal(config) {
        const modalEl = document.getElementById('claimReviewModal');
        const titleEl = document.getElementById('claimReviewModalTitle');
        const bodyEl = document.getElementById('claimReviewModalBody');
        const footerEl = document.getElementById('claimReviewModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultClaims() {
        return [
            { id: 'CLM-801', employee: 'Anna Santos', category: 'Medical', amount: 2500, date: '2026-02-25', notes: 'Outpatient consultation', status: 'Submitted', reimbursed: false },
            { id: 'CLM-802', employee: 'Jude Molina', category: 'Transportation', amount: 850, date: '2026-02-26', notes: 'Official field visit', status: 'Approved', reimbursed: true },
            { id: 'CLM-803', employee: 'Leah Gomez', category: 'Training', amount: 3200, date: '2026-02-28', notes: 'Certification course', status: 'Under Review', reimbursed: false }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderClaimReview = function (container) {
        ensureClaimReviewModalHost();

        let claims = getStorageList(CLAIMS_RECORDS_KEY, defaultClaims);

        function render() {
            const reviewQueue = claims.filter(function (item) {
                return item.status === 'Submitted' || item.status === 'Under Review';
            });

            container.innerHTML = [
                '<div class="card border-0 shadow-sm claim-review-submodule">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-clipboard-check text-primary me-2"></i>Claim Review Queue</h5>',
                '    <span class="badge bg-warning-subtle text-warning">' + reviewQueue.length + ' In Review</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Category</th><th>Amount</th><th>Notes</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                reviewQueue.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.category + '</td>'
                        + '<td>₱' + Number(item.amount).toLocaleString() + '</td>'
                        + '<td>' + item.notes + '</td>'
                        + '<td><span class="badge bg-info-subtle text-info">' + item.status + '</span></td>'
                        + '<td>'
                        + '<button class="btn btn-sm btn-outline-primary me-1" data-action="review" data-id="' + item.id + '">Mark Review</button>'
                        + '<button class="btn btn-sm btn-outline-success me-1" data-action="approve" data-id="' + item.id + '">Approve</button>'
                        + '<button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.id + '">Reject</button>'
                        + '</td>'
                        + '</tr>';
                }).join(''),
                reviewQueue.length ? '' : '<tr><td colspan="7" class="text-center text-muted py-3">No claims for review.</td></tr>',
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const action = button.getAttribute('data-action');
                    const id = button.getAttribute('data-id');
                    const target = claims.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    const nextStatus = action === 'approve'
                        ? 'Approved'
                        : action === 'reject'
                            ? 'Rejected'
                            : 'Under Review';

                    showClaimReviewModal({
                        title: 'Update Claim Status',
                        message: 'Set claim ' + target.id + ' for ' + target.employee + ' to ' + nextStatus + '?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmClaimReviewActionBtn">Confirm</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmClaimReviewActionBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                claims = claims.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }

                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        category: item.category,
                                        amount: item.amount,
                                        date: item.date,
                                        notes: item.notes,
                                        status: nextStatus,
                                        reimbursed: item.reimbursed === true
                                    };
                                });

                                setStorageList(CLAIMS_RECORDS_KEY, claims);
                                modal.hide();
                                render();

                                showClaimReviewModal({
                                    title: 'Claim Updated',
                                    message: 'Claim ' + target.id + ' is now ' + nextStatus + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);
