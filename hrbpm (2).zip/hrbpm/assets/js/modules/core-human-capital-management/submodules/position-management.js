window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const POSITIONS_KEY = 'hospitalHrHcmPositions';

    function ensurePositionManagementModalHost() {
        if (document.getElementById('positionManagementModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="positionManagementModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="positionManagementModalTitle">Position Management</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="positionManagementModalBody"></div>',
            '      <div class="modal-footer" id="positionManagementModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showPositionManagementModal(config) {
        const modalEl = document.getElementById('positionManagementModal');
        const titleEl = document.getElementById('positionManagementModalTitle');
        const bodyEl = document.getElementById('positionManagementModalBody');
        const footerEl = document.getElementById('positionManagementModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultPositions() {
        return [
            { id: 'POS-301', title: 'HR Manager', department: 'Human Resources', headcount: 1, filled: 1 },
            { id: 'POS-302', title: 'Payroll Analyst', department: 'Finance', headcount: 2, filled: 1 },
            { id: 'POS-303', title: 'Clinic Coordinator', department: 'Operations', headcount: 1, filled: 0 }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();

        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderPositionManagement = function (container) {
        ensurePositionManagementModalHost();

        let positions = getStorageList(POSITIONS_KEY, defaultPositions);

        function render() {
            const openCount = positions.filter(function (item) { return Number(item.filled) < Number(item.headcount); }).length;

            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 position-management-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-briefcase text-primary me-2"></i>Create Position</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-4"><input id="hcmPosTitle" class="form-control" placeholder="Position Title"></div>',
                '      <div class="col-md-3"><input id="hcmPosDepartment" class="form-control" placeholder="Department"></div>',
                '      <div class="col-md-2"><input id="hcmPosHeadcount" type="number" min="1" class="form-control" placeholder="Headcount"></div>',
                '      <div class="col-md-2"><input id="hcmPosFilled" type="number" min="0" class="form-control" placeholder="Filled"></div>',
                '      <div class="col-md-1"><button id="hcmPosAddBtn" class="btn btn-primary w-100">Add</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-sitemap text-primary me-2"></i>Position Management</h5>',
                '    <span class="badge bg-warning-subtle text-warning">' + openCount + ' Open Positions</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Position ID</th><th>Title</th><th>Department</th><th>Headcount</th><th>Filled</th><th>Action</th></tr></thead>',
                '      <tbody>',
                positions.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.title + '</td>'
                        + '<td>' + item.department + '</td>'
                        + '<td>' + item.headcount + '</td>'
                        + '<td>' + item.filled + '</td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="fill" data-id="' + item.id + '">Add Occupant</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('hcmPosAddBtn');
            if (addButton) {
                addButton.addEventListener('click', function () {
                    const title = (document.getElementById('hcmPosTitle').value || '').trim();
                    const department = (document.getElementById('hcmPosDepartment').value || '').trim();
                    const headcount = Number(document.getElementById('hcmPosHeadcount').value || 0);
                    const filled = Number(document.getElementById('hcmPosFilled').value || 0);

                    if (!title || !department || !headcount) {
                        showPositionManagementModal({
                            title: 'Incomplete Position',
                            message: 'Provide position title, department, and headcount before adding.'
                        });
                        return;
                    }

                    const nextId = 'POS-' + (300 + positions.length + 1);
                    positions.unshift({
                        id: nextId,
                        title: title,
                        department: department,
                        headcount: headcount,
                        filled: filled > headcount ? headcount : filled
                    });

                    setStorageList(POSITIONS_KEY, positions);
                    render();
                    showPositionManagementModal({
                        title: 'Position Added',
                        message: 'Position ' + nextId + ' (' + title + ') has been created.'
                    });
                });
            }

            container.querySelectorAll('button[data-action="fill"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = positions.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showPositionManagementModal({
                        title: 'Add Occupant',
                        message: 'Increase filled count for ' + target.id + ' (' + target.title + ')?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmPositionFillBtn">Confirm</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmPositionFillBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                positions = positions.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }

                                    const nextFilled = Number(item.filled) + 1;
                                    return {
                                        id: item.id,
                                        title: item.title,
                                        department: item.department,
                                        headcount: item.headcount,
                                        filled: nextFilled > Number(item.headcount) ? Number(item.headcount) : nextFilled
                                    };
                                });

                                setStorageList(POSITIONS_KEY, positions);
                                modal.hide();
                                render();

                                showPositionManagementModal({
                                    title: 'Occupant Added',
                                    message: 'Filled count for ' + target.id + ' has been updated.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);
