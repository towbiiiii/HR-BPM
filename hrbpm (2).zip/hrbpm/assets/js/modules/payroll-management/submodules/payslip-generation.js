window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const PAYROLL_KEY = 'hospitalHrPayrollRecords';

    function ensurePayslipGenerationModalHost() {
        if (document.getElementById('payslipGenerationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="payslipGenerationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="payslipGenerationModalTitle">Payslip Generation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="payslipGenerationModalBody"></div>',
            '      <div class="modal-footer" id="payslipGenerationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showPayslipGenerationModal(config) {
        const modalEl = document.getElementById('payslipGenerationModal');
        const titleEl = document.getElementById('payslipGenerationModalTitle');
        const bodyEl = document.getElementById('payslipGenerationModalBody');
        const footerEl = document.getElementById('payslipGenerationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultPayroll() {
        return [
            { id: 'PAY-9001', employee: 'Anna Santos', period: '2026-03-15', base: 32000, overtime: 1800, deductions: 2400, net: 31400, status: 'Ready', payslip: false },
            { id: 'PAY-9002', employee: 'Jude Molina', period: '2026-03-15', base: 28500, overtime: 950, deductions: 2100, net: 27350, status: 'Processed', payslip: true },
            { id: 'PAY-9003', employee: 'Leah Gomez', period: '2026-03-15', base: 30000, overtime: 1200, deductions: 2200, net: 29000, status: 'Ready', payslip: false }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderPayslipGeneration = function (container) {
        ensurePayslipGenerationModalHost();

        let payroll = getStorageList(PAYROLL_KEY, defaultPayroll);

        function render() {
            const readyForPayslip = payroll.filter(function (item) {
                return item.status === 'Processed' && item.payslip !== true;
            });

            const generatedCount = payroll.filter(function (item) { return item.payslip === true; }).length;

            container.innerHTML = [
                '<div class="row g-3 mb-3 payslip-generation-submodule">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Ready for Payslip</p><h5 class="mb-0">' + readyForPayslip.length + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Generated Payslips</p><h5 class="mb-0">' + generatedCount + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Distribution Status</p><h5 class="mb-0">Ready</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-file-invoice-dollar text-primary me-2"></i>Payslip Generation</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Payroll ID</th><th>Employee</th><th>Period</th><th>Net Pay</th><th>Payslip</th><th>Action</th></tr></thead>',
                '      <tbody>',
                payroll.map(function (item) {
                    const payslipBadge = item.payslip === true
                        ? '<span class="badge bg-success-subtle text-success">Generated</span>'
                        : '<span class="badge bg-warning-subtle text-warning">Pending</span>';
                    const disabled = item.status !== 'Processed' || item.payslip === true ? ' disabled' : '';

                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.period + '</td>'
                        + '<td>₱' + Number(item.net).toLocaleString() + '</td>'
                        + '<td>' + payslipBadge + '</td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="generate" data-id="' + item.id + '"' + disabled + '>Generate</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="generate"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = payroll.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showPayslipGenerationModal({
                        title: 'Generate Payslip',
                        message: 'Generate payslip for ' + target.employee + ' (' + target.id + ')?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmPayslipGenerationBtn">Generate</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmPayslipGenerationBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                payroll = payroll.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        period: item.period,
                                        base: item.base,
                                        overtime: item.overtime,
                                        deductions: item.deductions,
                                        net: item.net,
                                        status: item.status,
                                        payslip: true
                                    };
                                });
                                setStorageList(PAYROLL_KEY, payroll);
                                modal.hide();
                                render();

                                showPayslipGenerationModal({
                                    title: 'Payslip Generated',
                                    message: 'Payslip for ' + target.employee + ' has been generated successfully.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);
