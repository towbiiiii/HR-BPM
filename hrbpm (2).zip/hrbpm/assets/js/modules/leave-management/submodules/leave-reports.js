window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const LEAVE_REQUESTS_KEY = 'hospitalHrLeaveRequests';

    function ensureLeaveReportsModalHost() {
        if (document.getElementById('leaveReportsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="leaveReportsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="leaveReportsModalTitle">Leave Reports</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="leaveReportsModalBody"></div>',
            '      <div class="modal-footer" id="leaveReportsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showLeaveReportsModal(config) {
        const modalEl = document.getElementById('leaveReportsModal');
        const titleEl = document.getElementById('leaveReportsModalTitle');
        const bodyEl = document.getElementById('leaveReportsModalBody');
        const footerEl = document.getElementById('leaveReportsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = (config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultRequests() {
        return [
            { id: 'LV-701', employee: 'Anna Santos', type: 'Vacation', from: '2026-03-10', to: '2026-03-12', days: 3, reason: 'Family trip', status: 'Approved' },
            { id: 'LV-702', employee: 'Jude Molina', type: 'Sick', from: '2026-03-04', to: '2026-03-05', days: 2, reason: 'Flu recovery', status: 'Pending' },
            { id: 'LV-703', employee: 'Leah Gomez', type: 'Emergency', from: '2026-03-02', to: '2026-03-02', days: 1, reason: 'Family emergency', status: 'Pending' }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    registry.renderLeaveReports = function (container) {
        ensureLeaveReportsModalHost();

        const requests = getStorageList(LEAVE_REQUESTS_KEY, defaultRequests);
        const typeSummary = { Vacation: 0, Sick: 0, Emergency: 0 };

        requests.forEach(function (item) {
            if (typeof typeSummary[item.type] !== 'number') {
                typeSummary[item.type] = 0;
            }
            typeSummary[item.type] += Number(item.days || 0);
        });

        const rows = Object.keys(typeSummary).map(function (type) {
            return '<tr><td>' + type + '</td><td>' + typeSummary[type] + '</td></tr>';
        }).join('');

        container.innerHTML = [
            '<div class="d-flex justify-content-between align-items-center mb-3 leave-reports-submodule"><h6 class="mb-0"><i class="fas fa-chart-pie text-primary me-2"></i>Leave Reports</h6><button id="leaveExportCsv" class="btn btn-outline-secondary btn-sm">Export CSV</button></div>',
            '<div class="row g-3 mb-3">',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Requests</p><h5 class="mb-0">' + requests.length + '</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Approved</p><h5 class="mb-0">' + requests.filter(function (item) { return item.status === 'Approved'; }).length + '</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Pending</p><h5 class="mb-0">' + requests.filter(function (item) { return item.status === 'Pending'; }).length + '</h5></div></div>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-chart-column text-primary me-2"></i>Leave Days by Type</h5></div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>Leave Type</th><th>Total Days</th></tr></thead>',
            '      <tbody>' + rows + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');

        const exportButton = document.getElementById('leaveExportCsv');
        if (exportButton) {
            exportButton.addEventListener('click', function () {
                showLeaveReportsModal({
                    title: 'Export Leave CSV',
                    message: 'Download the leave report as a CSV file?',
                    footerHtml: [
                        '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                        '<button type="button" class="btn btn-primary" id="confirmLeaveExportBtn">Export</button>'
                    ].join(''),
                    onShown: function (modal) {
                        const confirmBtn = document.getElementById('confirmLeaveExportBtn');
                        if (!confirmBtn) {
                            return;
                        }

                        confirmBtn.addEventListener('click', function () {
                            const csvLines = ['ID,Employee,Type,From,To,Days,Status'];
                            requests.forEach(function (item) {
                                csvLines.push([item.id, item.employee, item.type, item.from, item.to, item.days, item.status].join(','));
                            });

                            const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
                            const link = document.createElement('a');
                            link.href = URL.createObjectURL(blob);
                            link.download = 'leave-reports.csv';
                            link.click();
                            URL.revokeObjectURL(link.href);
                            modal.hide();

                            showLeaveReportsModal({
                                title: 'Export Complete',
                                message: 'Leave report CSV has been downloaded.'
                            });
                        }, { once: true });
                    }
                });
            });
        }
    };
})(window.HRSubmodules);
