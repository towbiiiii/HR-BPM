const HR3_STORAGE_KEY = 'hr3WorkforceSummary';
  const LEAVE_REQUESTS_KEY = 'leaveRequestsData';

  function normalizeDepartment(value) {
    const key = String(value || '').trim().toLowerCase();
    const map = {
      'emergency & triage': 'Emergency',
      'intensive care unit': 'ICU'
    };
    return map[key] || value;
  }

  function parseDateToIso(dateText) {
    const value = String(dateText || '').trim();
    const isoLike = /^\d{4}-\d{2}-\d{2}$/;
    if (isoLike.test(value)) return value;

    const dmy = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
    const match = value.match(dmy);
    if (match) {
      const day = match[1].padStart(2, '0');
      const month = match[2].padStart(2, '0');
      const year = match[3];
      return `${year}-${month}-${day}`;
    }

    const parsed = new Date(value);
    if (!Number.isNaN(parsed.getTime())) {
      return parsed.toISOString().split('T')[0];
    }

    return '';
  }

  function countLeaveDays(startIso, endIso) {
    if (!startIso || !endIso) return 1;
    const start = new Date(startIso + 'T00:00:00');
    const end = new Date(endIso + 'T00:00:00');
    const diff = Math.floor((end - start) / (1000 * 60 * 60 * 24));
    return Number.isNaN(diff) ? 1 : Math.max(1, diff + 1);
  }

  function saveLeaveRequestRecord() {
    try {
      const staffId = (document.querySelector('.staff-info-row .staff-field:first-child .field-value span:first-child')?.innerText || 'EMP-0000').replace(/\u2011/g, '-').trim();
      const employee = (document.querySelector('.staff-info-row .staff-field:nth-child(2) .field-value span')?.innerText || 'Unknown Employee').trim();
      const deptRaw = document.querySelector('.form-grid select')?.value || 'N/A';
      const department = normalizeDepartment(deptRaw);
      const checkedLeave = document.querySelector('.leave-type-item input[type="checkbox"]:checked');
      const leaveType = checkedLeave ? checkedLeave.value : 'Vacation Leave';
      const dateInputs = document.querySelectorAll('.form-grid .input-group input[type="text"]');
      const startDate = parseDateToIso(dateInputs[0]?.value || '');
      const endDate = parseDateToIso(dateInputs[1]?.value || startDate);
      const days = countLeaveDays(startDate, endDate);

      if (!startDate || !endDate) return;

      const row = {
        id: `leave-${Date.now()}`,
        staffId,
        employee,
        department,
        leaveType,
        startDate,
        endDate,
        days,
        status: 'Pending',
        createdAt: new Date().toISOString()
      };

      const current = JSON.parse(localStorage.getItem(LEAVE_REQUESTS_KEY) || '[]');
      current.unshift(row);
      localStorage.setItem(LEAVE_REQUESTS_KEY, JSON.stringify(current));
      window.dispatchEvent(new CustomEvent('leave:records-updated'));
    } catch (e) {}
  }

  function addPendingLeaveRequestToSummary() {
    try {
      const current = JSON.parse(localStorage.getItem(HR3_STORAGE_KEY) || '{}');
      const pending = Number(current.onLeavePending || 0) + 1;
      const approved = Number(current.onLeaveApproved || 0);
      const next = {
        ...current,
        onLeavePending: pending,
        onLeaveApproved: approved,
        onLeaveTotal: pending + approved
      };
      localStorage.setItem(HR3_STORAGE_KEY, JSON.stringify(next));
      window.dispatchEvent(new CustomEvent('hr3:refresh-summary'));
    } catch (e) {}
  }

  function clearForm() {
    const staffIdSpan = document.querySelector('.staff-info-row .staff-field:first-child .field-value span:first-child');
    if (staffIdSpan) {
      staffIdSpan.innerText = 'EMP‑2145';
      staffIdSpan.removeAttribute('style');
      staffIdSpan.style.border = '1px dashed #bdd3e3';
      staffIdSpan.style.padding = '4px 12px';
      staffIdSpan.style.borderRadius = '30px';
    }

    const nameSpan = document.querySelector('.staff-info-row .staff-field:nth-child(2) .field-value span');
    if (nameSpan) nameSpan.innerText = 'Maria Santos';

    // department select reset to first disabled option
    const deptSelect = document.querySelector('select');
    if (deptSelect) deptSelect.selectedIndex = 0;
    
    // checkboxes: uncheck all except vacation leave (to match original mock)
    document.querySelectorAll('.leave-type-item input[type="checkbox"]').forEach(cb => {
      if (cb.value === 'Vacation Leave') {
        cb.checked = true;
      } else {
        cb.checked = false;
      }
    });
    
    // dates
    const dateInputs = document.querySelectorAll('.input-group input[type="text"]');
    if (dateInputs.length >= 2) {
      dateInputs[0].value = 'dd/mm/yyyy';
      dateInputs[1].value = 'dd/mm/yyyy';
    }
    
    // reason textarea
    const reasonTA = document.querySelector('textarea');
    if (reasonTA) reasonTA.value = '';
  }

  document.getElementById('submitLeaveBtn')?.addEventListener('click', function() {
    const button = this;
    const originalHtml = button.innerHTML;
    saveLeaveRequestRecord();
    addPendingLeaveRequestToSummary();
    button.innerHTML = '<i class="fas fa-check"></i> Submitted';
    button.disabled = true;
    setTimeout(() => {
      button.innerHTML = originalHtml;
      button.disabled = false;
    }, 1200);
  });

  document.querySelector('.search-icon-btn')?.addEventListener('click', function(e) {
    const nameSpan = document.querySelector('.staff-info-row .staff-field:nth-child(2) .field-value span');
    if (nameSpan) nameSpan.innerText = 'Maria Santos';

    const staffIdSpan = document.querySelector('.staff-info-row .staff-field:first-child .field-value span:first-child');
    if (staffIdSpan) staffIdSpan.setAttribute('style', 'border:1px dashed #5d87ff; padding:4px 12px; border-radius:30px;');

    const deptSelect = document.querySelector('select');
    if (deptSelect) deptSelect.value = 'Human Resources';
  });